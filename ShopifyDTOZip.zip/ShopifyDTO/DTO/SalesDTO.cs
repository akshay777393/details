﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopifyDTO.DTO
{
    public class SalesDTO
    {
        private string productid;
        private string productname;
        private double unitprice;
        private double quantity;
        private string supplierid;
        private string salesid;
        private double total;
        private double totalSale;
        private double customerNumber;
        private string salesdate;

        public String Productid
        {
            get { return productid; }
            set
            {
                productid = value;
            }
        }
        
        public String Productname
        {
            get { return productname; }
            set
            {
                productname = value;
            }
        }
        
        public double Unitprice
        {
            get { return unitprice; }
            set
            {
                unitprice = value;
            }
        }
        
        public double Quantity
        {
            get { return quantity; }
            set
            {
                quantity = value;
            }
        }
        
        public String Supplierid
        {
            get { return supplierid; }
            set
            {
                supplierid = value;
            }
        }

       
        public String Salesid
        {
            get { return salesid; }
            set
            {
                salesid = value;
            }
        }

       
        public double Total
        {
            get { return total; }
            set
            {
                total = value;
            }
        }

        
        public double TotalSale
        {
            get { return totalSale; }
            set
            {
                totalSale = value;
            }
        }

        
        public double CustomerNumber
        {
            get { return customerNumber; }
            set
            {
                customerNumber = value;
            }
        }

        public string Salesdate
        {
            get { return salesdate; }
            set { salesdate = value; }
        }
    }
}
