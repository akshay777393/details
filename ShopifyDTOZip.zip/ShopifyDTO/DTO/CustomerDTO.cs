﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopifyDTO.DTO
{
   public class CustomerDTO
    {


        private string customerid;
        private double customerNumber;
       
        private string customerName;

        public String Customerid
        {
            get { return customerid; }
            set
            {
                customerid = value;
            }
        }

        public double CustomerNumber
        {
            get { return customerNumber; }
            set
            {
                customerNumber = value;
            }
        }

        public String CustomerName
        {
            get { return customerName; }
            set
            {
                customerName = value;
            }
        }
    }
}
