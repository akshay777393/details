﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopifyDTO.DTO
{
   public class PurchaseDTO
    {


        private string purchaseid;
        private double totalPrice;
        private string date;
        private string supplierid;

        public String Purchaseid
        {
            get { return purchaseid; }
            set
            {
                purchaseid = value;
            }
        }
        
        public double TotalPrice
        {
            get { return totalPrice; }
            set
            {
                totalPrice = value;
            }
        }

        public String Supplierid
        {
            get { return supplierid; }
            set
            {
                supplierid = value;
            }
        }
        
        public String Date
        {
            get { return date; }
            set
            {
                date = value;
            }
        }
    }
}
