﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ShopifyDTO.DTO;
using ShopifyDSL.Helper;

namespace ShopifyDSL.DL
{
   public  class UserDSL
    {


        //insert users------------------------------------------------

        public static int InsertUser(UserDTO userDTO)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {

                sql = "insert into UserDetails(UserId,Name,Gender,ContactNumber,Type,PassWord) values(";
                sql = sql + "'" + userDTO.UserId + "',";
                sql = sql + "'" + userDTO.Name + "',";
                sql = sql + "'" + userDTO.Gender + "',";
                sql = sql + userDTO.ContactNumber + ",";
                sql = sql + "'" + userDTO.Type + "',";             
                sql = sql + "'" + userDTO.Password + "')";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*** Error : ShopifyItemsDSL.cs: InsertUser" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }


        
        //UserChangePassword--------------------------------------
        
        public static int ChangePassword(UserDTO userDTO)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataAdapter adapter = null;

            try
            {
                
                sql = "update UserDetails set PassWord='" + userDTO.NewPassword + "' where UserId='"+userDTO.UserId+"'";
                con = DBHelper.GetConnection(); con.Open();

                adapter = new SqlDataAdapter(sql, con);
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("***Error:ShopifyItemsDSL.cs:UserLogin()", ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }
            return output;
        }


        //UserLogin--------------------------------------------------


        public static DataSet UserLogin(UserDTO userDTO)
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsUser = null;
            try
            {
                sql = "select UserId,PassWord from UserDetails where Type='"+userDTO.Type+"'";
                con = DBHelper.GetConnection(); con.Open();
                dsUser = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsUser);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("***Error:ShopifyItemsDSL.cs:UserLogin()", ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }
            return dsUser;
        }


        //delete user------------------------------------------



        public static int DeleteItem(string id)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                
                sql = " delete from UserDetails where UserId='" + id + "'";
                
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : ShopifyItemsDSL.cs:DeleteItem()" + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }



        //load userid--------------------------------------------------------

        public static DataSet GetUserID()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsStockID = null;

            try
            {
                sql = "select UserId from UserDetails";
                con = DBHelper.GetConnection();
                con.Open();
                dsStockID = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsStockID);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : ShopifyItemsDSL.cs:GetContactIDs()" + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsStockID;
        }



        //deleting by id-------------------------------------------------

        public static UserDTO GetUserIdByDL(string userId)
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsUserdetails = null;

            UserDTO userDTO = null;

            try
            {
                sql = "Select UserID,Name,ContactNumber from UserDetails where UserId='" + userId + "'";

                con = DBHelper.GetConnection();
                con.Open();

                dsUserdetails = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsUserdetails);
                object[] Data = null;
                if (dsUserdetails.Tables[0].Rows.Count > 0)
                {
                    Data = dsUserdetails.Tables[0].Rows[0].ItemArray;
                    userDTO = new UserDTO();
                    userDTO.UserId = Data[0].ToString();
                    userDTO.Name = Data[1].ToString();
                    userDTO.ContactNumber = Data[2].ToString();
                      

                }

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : SalesDSL.cs:GetproductbyIdDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return userDTO;

        }
    }
}
