﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ShopifyDSL.DL;
using ShopifyDTO.DTO;
using ShopifyDSL.Helper;
namespace ShopifyDSL.DL
{
    public class PurchaseDSL
    {

        //Auto incrementation of Purchase ID-----------------------------------

        public static String GetLastPurchaseIdDL()
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsSales = null;
            string LastPurchaseId = null;
            Object[] Data = null;

            try
            {
                sql = "Select PurchaseID from PurchaseHistory order by PurchaseID desc";

                con = DBHelper.GetConnection();
                con.Open();

                dsSales = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSales);

                if (dsSales.Tables[0].Rows.Count > 0)
                {
                    Data = dsSales.Tables[0].Rows[0].ItemArray;
                    LastPurchaseId = Data[0].ToString();
                }
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseDSL.cs:GetLastPurchaseIdDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return LastPurchaseId;
        }


        //Get puchase Report--------------------------------------

        public static DataSet GetPurchaseReportDL(string supplier,string Date)
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet sales = null;

            try
            {

                sql = "Select * from StockDetails where SupplierID= '"+supplier+"' and Date ='"+Date+"'";  

                con = DBHelper.GetConnection();
                con.Open();

                sales = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(sales);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseDSL.cs:GetPurchaseReportDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return sales;
        }


        //Method to attain Total---------------------------

        public static string GetTotalDL(string supplier, string Date)
        {


            string sql = "";

            SqlConnection con = null;
            SqlCommand cmd = null;


            SqlDataAdapter adapter = null;
            DataSet dsSales = null;
            string total = null;
            Object[] Data = null;
            
            try
            {

                sql = "Select SUM(stockTotal) from StockDetails where SupplierID= '" + supplier + "' and Date ='" + Date + "'";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                dsSales = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSales);

                if (dsSales.Tables[0].Rows.Count > 0)
                {
                    Data = dsSales.Tables[0].Rows[0].ItemArray;
                    total = Data[0].ToString();
                }


            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseDSL.cs:GetTotalDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return total;


        }

        //Purchase Inserting--------------------------------------

        public static int PurchaseInsertDL(PurchaseDTO purchaseDTO)
        {
            int output = 0;
            string sql = "";

            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "INSERT INTO purchaseHistory(PurchaseID,TotalPrice,Date,SupplierID) values(";
                sql = sql + "'" + purchaseDTO.Purchaseid + "',";
                sql = sql + "" + purchaseDTO.TotalPrice + ",";
                sql = sql + "'" + purchaseDTO.Date + "',";
                sql = sql + "'" + purchaseDTO.Supplierid + "')";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseDSL.cs:PurchaseInsertDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }

        //PurchaseBillDL------------------------------------

        public static int PurchaseBillDL(PurchaseDTO purchaseDTO)
        {
           
            string sql = "";

            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataAdapter adapter = null;
            DataSet dsPurchase = null;
            int total = 0;
            Object[] Data = null;

            try
            {
                sql = "Select TotalPrice from purchaseHistory where SupplierID= '" + purchaseDTO.Supplierid + "' and Date ='" + purchaseDTO.Date + "'";

         

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                dsPurchase = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsPurchase);



                if (dsPurchase.Tables[0].Rows.Count > 0)
                {
                    Data = dsPurchase.Tables[0].Rows[0].ItemArray;
                    total = Convert.ToInt32(Data[0]);
                }
                
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseDSL.cs:PurchaseBillDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return total;

        }


        //PURCHASE REPORT------------------------------------

        public static DataSet GetPurchaseReportDL()
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet purchase = null;

            try
            {

                sql = "Select * from PurchaseHistory";

                con = DBHelper.GetConnection();
                con.Open();

                purchase = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(purchase);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseDSL.cs:GetPurchaseReportDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return purchase;
        }

    }
}
