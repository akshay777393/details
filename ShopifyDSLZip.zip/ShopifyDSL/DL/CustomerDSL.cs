﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using ShopifyDSL.DL;
using ShopifyDTO.DTO;
using ShopifyDSL.Helper;

namespace ShopifyDSL.DL
{
    public class CustomerDSL
    {

        //Customer Insert by cashier-------------------------------------

        public static int CustomerInsertDL(CustomerDTO customerDTO)
        {
            int output = 0;
            string sql = "";

            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {


                sql = "INSERT INTO CustomerDetails(CustomerID,Name,ContactNumber) values(";
                sql = sql + "'" + customerDTO.Customerid + "',";
                sql = sql + "'" + customerDTO.CustomerName + "',";
                sql = sql + customerDTO.CustomerNumber+ ")";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : CustomerDSL.cs:CustomerInsertDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }



        //Loadin Customer Number in Sales--------------------------------------

        public static DataSet GetCustomerNumberDL()
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet product = null;

            try
            {
                sql = "Select * from CustomerDetails";

                con = DBHelper.GetConnection();
                con.Open();

                product = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(product);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : CustomerDSL.cs:GetCustomerNumberDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return product;
        }
    }
}
