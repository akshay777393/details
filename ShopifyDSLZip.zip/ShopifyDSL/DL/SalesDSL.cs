﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ShopifyDSL.DL;
using ShopifyDTO.DTO;
using ShopifyDSL.Helper;

namespace ShopifyDSL.DL
{
    public class SalesDSL
    {
       


        //Load Product ID--------------------------

        public static DataSet GetProductIdsDL()
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet product = null;

            try
            {
                sql = "Select * from StockDetails";

                con = DBHelper.GetConnection();
                con.Open();

                product = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(product);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : SalesDSL.cs:GetProductIdsDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return product;
        }


        //Load Product Name in Sales-------------------------------

        public static DataSet GetProductNamesDL()
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet product = null;

            try
            {
                sql = "Select * from StockDetails";

                con = DBHelper.GetConnection();
                con.Open();

                product = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(product);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : SalesDSL.cs:GetProductIdsDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return product;
        }


        //Load details into Form Using ProductID---------------------------------

        public static SalesDTO GetproductbyIdDL(string productId)
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsProduct = null;

            SalesDTO product = null;

            try
            {
                sql = "Select * from StockDetails where ProductID='" + productId + "'";

                con = DBHelper.GetConnection();
                con.Open();

                dsProduct = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsProduct);

                Object[] Data = null;

                if (dsProduct.Tables[0].Rows.Count > 0)
                {
                    Data = dsProduct.Tables[0].Rows[0].ItemArray;
                    product = new SalesDTO();

                    product.Productid = Data[0].ToString();
                    product.Productname = Data[1].ToString();
                    product.Unitprice = Convert.ToInt64(Data[2].ToString());
                }

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : SalesDSL.cs:GetproductbyIdDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return product;

        }

        //Load details into Form Using Product Name---------------------------------

        public static SalesDTO GetproductbyNameDL(string productName)
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsProduct = null;

            SalesDTO product = null;

            try
            {
                sql = "Select * from StockDetails where ProductName='" + productName + "'";

                con = DBHelper.GetConnection();
                con.Open();

                dsProduct = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsProduct);

                Object[] Data = null;

                if (dsProduct.Tables[0].Rows.Count > 0)
                {
                    Data = dsProduct.Tables[0].Rows[0].ItemArray;
                    product = new SalesDTO();

                    product.Productid = Data[0].ToString();
                    product.Productname = Data[1].ToString();
                    product.Unitprice = Convert.ToInt64(Data[2].ToString());
                }

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : SalesDSL.cs:GetproductbyNameDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return product;

        }

        // Load Sales Report-------------------------------

        public static DataSet GetSalesReportDL()
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet sales = null;

            try
            {
               
                sql ="Select * from Sales";
                
                con = DBHelper.GetConnection();
                con.Open();

                sales = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(sales);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : SalesDSL.cs:GetSalesDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return sales;
        }


        //----------------------Load Sales details in Grid Table------------------------------------
        public static DataSet GetSalesDL(string ShowIdBill)
        {
            string sql = "";

            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet sales = null;

            try
            {
                sql = " Select StockDetails.ProductName,SalesHistory.UnitPrice,SalesHistory.Quantity,SalesHistory.TotalPrice from SalesHistory join StockDetails on SalesHistory.ProductID = StockDetails.ProductID where SalesID = '" + ShowIdBill + "'";
           

                con = DBHelper.GetConnection();
                con.Open();

                sales = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(sales);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : SalesDSL.cs:GetSalesDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return sales;
        }


        //Insert Sales----------------------------------

        public static int SaleEachInsertDL(SalesDTO shopifyItems)
        {
            int output = 0;
            string sql = "";

            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {


                sql = "INSERT INTO SalesHistory(SalesID,ProductID,UnitPrice,Quantity,Date,TotalPrice) values(";
                sql = sql + "'" + shopifyItems.Salesid + "',";
                sql = sql + "'" + shopifyItems.Productid + "',";
                sql = sql + shopifyItems.Unitprice + ",";
                sql = sql + shopifyItems.Quantity + ",";
                sql = sql + shopifyItems.Salesdate + ",";
                sql = sql + "'" + shopifyItems.TotalSale + "')";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : ShopifyItemsDSL.cs:SaleEachInsertDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }


        //Find Sales Total--------------------------------------------------

        public static double GetTotalSaleDL(string SalesID)
        {
            string sql = "";

            SqlConnection con = null;
            SqlCommand cmd = null;


            SqlDataAdapter adapter = null;
            DataSet dsSales = null;
            string total = null;
            Object[] Data = null;


            try
            {

                sql = "Select SUM(TotalPrice) from SalesHistory where SalesID = '" + SalesID + "'";


                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);



                dsSales = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSales);

                if (dsSales.Tables[0].Rows.Count > 0)
                {
                    Data = dsSales.Tables[0].Rows[0].ItemArray;
                    total = Data[0].ToString();
                }

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : ShopifyItemsDSL.cs:GetTotalSaleDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return Convert.ToDouble(total);
        }




        public static int SalesInsertDL(SalesDTO salesDTO)
        {
            int output = 0;
            string sql = "";

            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "INSERT INTO Sales(SalesID,SalesDate,CustomerID,SalesTotal) values(";
                sql = sql + "'" + salesDTO.Salesid + "',";
                sql = sql + "'" + salesDTO.Salesdate + "',";
                sql = sql + "'" + salesDTO.CustomerNumber + "',";
                sql = sql + "'" + salesDTO.Total + "')";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : ShopifyItemsDSL.cs:SalesInsertDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }

        //Function to retrive last Sales ID

        public static String GetLastSalesIdDL()
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsSales = null;
            string LastSalesId = null;
            Object[] Data = null;

            try
            {
                sql = "Select SalesID from sales order by SalesID desc";

                con = DBHelper.GetConnection();
                con.Open();

                dsSales = new DataSet();

                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSales);

                if (dsSales.Tables[0].Rows.Count > 0)
                {
                    Data = dsSales.Tables[0].Rows[0].ItemArray;
                    LastSalesId = Data[0].ToString();
                }
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : StudentMarkDao.cs:GetLastStudentId:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }

            return LastSalesId;
        }
    }
}
