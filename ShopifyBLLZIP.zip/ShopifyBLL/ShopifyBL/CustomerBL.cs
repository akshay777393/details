﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using ShopifyDSL.DL;
using ShopifyDTO.DTO;
using ShopifyDSL.Helper;

namespace ShopifyBLL.ShopifyBL
{
    public class CustomerBL
    {

        //Add Customers--------------------

        public static int CustomerInsertBL(CustomerDTO customerDTO)
        {
            int output = 0;

            try
            {
                
                output = CustomerDSL.CustomerInsertDL(customerDTO);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : CustomerBL.cs:CustomerInsertBL:" + exe.Message.ToString());
            }
            return output;

        }


        //Load customer details by Contact Number--------------------------

        public static DataSet GetCustomerNumber()
        {
            DataSet CustomerNumber = null;

            try
            {
                CustomerNumber = CustomerDSL.GetCustomerNumberDL();

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : CustomerBL.cs:GetCustomerNumber:" + exe.Message.ToString());
            }

            return CustomerNumber;
        }
    }
}
