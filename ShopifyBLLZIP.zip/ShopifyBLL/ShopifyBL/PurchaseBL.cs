﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ShopifyDSL.DL;
using ShopifyDTO.DTO;
using ShopifyDSL.Helper;

namespace ShopifyBLL.ShopifyBL
{
    public class PurchaseBL
    {


        //Retrieve Purchase History------------------

        public static DataSet GetPurchaseReportBL(string supplierId,string date)
        {
            DataSet sales = null;

            try
            {
                sales = PurchaseDSL.GetPurchaseReportDL(supplierId,date);

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseBL.cs:GetPurchaseReportBL:" + exe.Message.ToString());
            }

            return sales;
        }



        //Find Total--------------------------------

        public static Double GetTotalBL(string supplierId, string date)
        {
            Double total=0;

            try
            {
                total =Convert.ToDouble(PurchaseDSL.GetTotalDL(supplierId, date));

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseBL.cs:GetPurchaseReportBL:" + exe.Message.ToString());
            }

            return total;
        }


        //Auto icrement ID----------------------------------

        public static String GetLastPurchaseId()
        {
            string LastPurchaseId = null;
            string newpurchaseId = null;

            try
            {
                LastPurchaseId = PurchaseDSL.GetLastPurchaseIdDL();
                if (LastPurchaseId != null)
                {
                    newpurchaseId = UtilityHelper.GeneratePurchaseID(LastPurchaseId);
                }
                else
                {
                    newpurchaseId = "PUR101";
                }
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseBL.cs:GetLastSalesIdBL:" + exe.Message.ToString());
            }

            return newpurchaseId;
        }

        
        //Purchase Insert-----------------------------------------

        public static int PurchaseEachInsertBL(PurchaseDTO purchase)
        {
            int output = 0;
            int output1 = 0;

            try
            {
                output1 = PurchaseDSL.PurchaseBillDL(purchase);
                if(output1 >0)
                {
                     output = 1;
                }
                else
                {
                    output = 0;
                }
               
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseBL.cs:PurchaseEachInsertBL:" + exe.Message.ToString());
            }
            return output;

        }


        public static int PurchaseInsertBL(PurchaseDTO purchase)
        {
            int output = 0;
         
            try
            {    
                 output = PurchaseDSL.PurchaseInsertDL(purchase);
              
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseBL.cs:PurchaseEachInsertBL:" + exe.Message.ToString());
            }
            return output;

        }


        //PURCHASE REPORT---------------------------

        public static DataSet GetPurchaseReportBL()
        {
            DataSet purchase = null;

            try
            {
                purchase = PurchaseDSL.GetPurchaseReportDL();

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PurchaseBL.cs:purchase:" + exe.Message.ToString());
            }

            return purchase;
        }

    }
}
