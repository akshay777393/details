﻿namespace Linq
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLoad = new System.Windows.Forms.Button();
            this.cbNumbers = new System.Windows.Forms.ComboBox();
            this.cbNames = new System.Windows.Forms.ComboBox();
            this.btnName = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtLoad
            // 
            this.txtLoad.Location = new System.Drawing.Point(84, 231);
            this.txtLoad.Name = "txtLoad";
            this.txtLoad.Size = new System.Drawing.Size(157, 23);
            this.txtLoad.TabIndex = 0;
            this.txtLoad.Text = "Load Number";
            this.txtLoad.UseVisualStyleBackColor = true;
            this.txtLoad.Click += new System.EventHandler(this.txtLoad_Click);
            // 
            // cbNumbers
            // 
            this.cbNumbers.FormattingEnabled = true;
            this.cbNumbers.Location = new System.Drawing.Point(84, 84);
            this.cbNumbers.Name = "cbNumbers";
            this.cbNumbers.Size = new System.Drawing.Size(157, 21);
            this.cbNumbers.TabIndex = 1;
            // 
            // cbNames
            // 
            this.cbNames.FormattingEnabled = true;
            this.cbNames.Location = new System.Drawing.Point(273, 83);
            this.cbNames.Name = "cbNames";
            this.cbNames.Size = new System.Drawing.Size(157, 21);
            this.cbNames.TabIndex = 2;
            // 
            // btnName
            // 
            this.btnName.Location = new System.Drawing.Point(273, 231);
            this.btnName.Name = "btnName";
            this.btnName.Size = new System.Drawing.Size(157, 23);
            this.btnName.TabIndex = 3;
            this.btnName.Text = "Load Name";
            this.btnName.UseVisualStyleBackColor = true;
            this.btnName.Click += new System.EventHandler(this.btnName_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 450);
            this.Controls.Add(this.btnName);
            this.Controls.Add(this.cbNames);
            this.Controls.Add(this.cbNumbers);
            this.Controls.Add(this.txtLoad);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button txtLoad;
        private System.Windows.Forms.ComboBox cbNumbers;
        private System.Windows.Forms.ComboBox cbNames;
        private System.Windows.Forms.Button btnName;
    }
}

