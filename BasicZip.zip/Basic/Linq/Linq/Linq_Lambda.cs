﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Linq
{
    public partial class Linq_Lambda : Form
    {
        Student[] studentArray =
        {
            new Student() { StudentId=1, StudentName="John",Age=18},
            new Student() { StudentId=2, StudentName="Abhilash",Age=22},
            new Student() { StudentId=3, StudentName="Bill",Age=20},
            new Student() { StudentId=4, StudentName="Roshan",Age=17},
            new Student() { StudentId=5, StudentName="Ram",Age=21},
            new Student() { StudentId=6, StudentName="Chris",Age=20},
            new Student() { StudentId=7, StudentName="Rob",Age=15},
        };




        public Linq_Lambda()
        {
            InitializeComponent();
        }

        private void btnLambda1_Click(object sender, EventArgs e)
        {
            List<Student> teenAgerStudents = studentArray.Where(s => s.Age > 12 && s.Age < 20).ToList();
            dgvLambda.DataSource = teenAgerStudents;
        }

        private void btnLambda2_Click(object sender, EventArgs e)
        {
            List<Student> teenAgerStudents = studentArray.Where(s => s.StudentName =="Bill").ToList();
            dgvLambda.DataSource = teenAgerStudents;
        }

        private void btnLambda3_Click(object sender, EventArgs e)
        {
            List<Student> teenAgerStudents = studentArray.Where(s1 => s1.StudentId==5).ToList();
            dgvLambda.DataSource = teenAgerStudents;
        }
    }

    class Student
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
    }
}
