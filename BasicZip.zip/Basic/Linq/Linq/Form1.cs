﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Linq
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void LoadNumber()
        {
            int[] Numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var LinqQuery = from num in Numbers
                            where (num % 2) == 0
                            select num;

           // List<int> lstNumbers = LinqQuery.ToList();

            cbNumbers.DataSource = LinqQuery.ToList();

            //foreach(int val in lstNumbers)
            //{
            //    Console.WriteLine("Val : " + val);
            //}

            //foreach (int val in lstNumbers)
            //{
            //    cbNumbers.Items.Add(val);
            //}
        }

        private void LoadName()
        {
            string[] Names = { "Bill","Steve","James","Mohan" };

            var myLinqQuery = from name in Names
                            where name.Contains('e')
                            select name;



            foreach (var name in myLinqQuery)
            {
                cbNames.Items.Add(name);
            }
        }

        private void txtLoad_Click(object sender, EventArgs e)
        {
            LoadNumber();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnName_Click(object sender, EventArgs e)
        {
            LoadName();
        }
    }
}
