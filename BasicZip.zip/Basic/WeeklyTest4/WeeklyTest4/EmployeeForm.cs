﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeeklyTest4
{
    public partial class EmployeeForm : Form
    {
        double BP, DA, GP, EMI, RI, loanAmount, loanTenure, R;
        string Hobbies = "";
        string Department;
        string gender;
        string Dob;


        public EmployeeForm()
        {
            InitializeComponent();
        }
        //public static void IsNumber(String str)
        //{
        //    try
        //    {
        //        Double.Parse(str);
        //        //return true;
        //    }
        //    catch (Exception es)
        //    {
        //        // lblMesage.Text = ""
        //        //return false;
        //        Console.Out.WriteLine("**************" + es.Message.ToString());
        //    }
        //}
        private void EmployeeForm_Load(object sender, EventArgs e)
        {

            cmbDept.Text = "Full-time";

         
        }

        private void Personal_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" EmpId\t\t: " + txtId.Text + " \n Employee Name\t: " + txtName.Text + "\n Department\t: " + Department + "\n Email Id\t\t: " + txtEmail.Text + "\n Mobile Number\t: " + txtMob.Text + "\n Gender\t\t: " + "Male" + "\n DOB \t\t: " + Dob + "\n Hobbies\t\t: " + Hobbies + "\n EMI\t\t: " + EMI);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtMob_TextChanged(object sender, EventArgs e)
        {
            lblMesage.Text = "";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" EmpId\t\t: " + txtId.Text + " \n Employee Name\t: " + txtName.Text + "\n Department\t: " + Department + "\n Email Id\t\t: " + txtEmail.Text + "\n Mobile Number\t: " + txtMob.Text + "\n Gender\t\t: " + "Male" + "\n DOB \t\t: " + Dob + "\n Hobbies\t\t: " + Hobbies + "\n EMI\t\t: " + EMI);
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            double mob;

            if (txtId.Text == string.Empty && txtName.Text == string.Empty && txtEmail.Text == string.Empty && txtMob.Text == string.Empty)
            {
                lblMesage.Text = "! All fields are mandatory. Enter Data to all fields";
                return;
            }
            else if (txtId.Text == string.Empty)
            {
                lblMesage.Text = "! Enter Employee ID";
                return;
            }
            else if (txtName.Text == string.Empty)
            {
                lblMesage.Text = "! Enter Employee Name";
                return;
            }
            else if (cmbDept.SelectedIndex == -1)
            {
                lblMesage.Text = "Please select a value from Department!";
                return;
            }
            else if (txtEmail.Text == string.Empty)
            {
                lblMesage.Text = "! Enter Employee Email";
                return;
            }
            else if (txtMob.Text == string.Empty)
            {
                lblMesage.Text = "! Enter Employee Mobile Number";
                return;
            }
            else if (!rdoMale.Checked && !rdoFemale.Checked)
            {
                lblMesage.Text = "Please choose one from Gender";
                return;
            }
            else if (txtMob.Text.Length < 10 || txtMob.Text.Length > 10)
            {
                lblMesage.Text = "Enter correct Mobile number";
            }
            else
            {
                    Department = cmbDept.Items[cmbDept.SelectedIndex].ToString();

                    Dob = dateTimePicker1.Value.ToString();


                    if (rdoMale.Checked == true)
                    {
                        gender = rdoMale.Text;

                    }
                    else if (rdoFemale.Checked == true)
                    {
                        gender = rdoFemale.Text;
                    }



                    if (chkB1.Checked)
                    {
                        Hobbies += chkB1.Text + " | ";
                    }
                    if (chkB2.Checked)
                    {
                        Hobbies += chkB2.Text + " | ";
                    }
                    if (chkB3.Checked)
                    {
                        Hobbies += chkB3.Text + " | ";
                    }
            }
            try
            {
                Department = cmbDept.Items[cmbDept.SelectedIndex].ToString();

                Dob = dateTimePicker1.Value.ToString();


                if (rdoMale.Checked == true)
                {
                    gender = rdoMale.Text;

                }
                else if (rdoFemale.Checked == true)
                {
                    gender = rdoFemale.Text;
                }



                if (chkB1.Checked)
                {
                    Hobbies += chkB1.Text + " | ";
                }
                if (chkB2.Checked)
                {
                    Hobbies += chkB2.Text + " | ";
                }
                if (chkB3.Checked)
                {
                    Hobbies += chkB3.Text + " | ";
                }

                MessageBox.Show(" EmpId\t\t: " + txtId.Text + " \n Employee Name\t: " + txtName.Text + "\n Department\t: " + Department + "\n Email Id\t\t: " + txtEmail.Text + "\n Mobile Number\t: " + txtMob.Text + "\n Gender\t\t: " + gender + "\n DOB \t\t: " + Dob + "\n Hobbies\t\t: " + Hobbies);
                
            }
            catch (Exception ez)
            {
                Console.Out.WriteLine("**************" + ez.Message.ToString());
            }
        }

        private void txtRI_TextChanged(object sender, EventArgs e)
        {
            R = RI / (12 * 100);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void Salary_Click(object sender, EventArgs e)
        {
        
        }

        private void butEmi_Click(object sender, EventArgs e)
        {
           

            try
            {

                BP = Convert.ToInt32(txtBS.Text);
                RI = Convert.ToInt32(txtRI.Text);
                loanAmount = Convert.ToInt32(txtLA.Text);
                loanTenure = Convert.ToInt32(txtTenure.Text);

                DA = BP * (30 / 100);
                GP = BP + DA;



                txtDA.Text = Convert.ToString(DA);
                txtGP.Text = Convert.ToString(GP);

                BP = Convert.ToDouble(txtBS.Text);
                RI = Convert.ToDouble(txtRI.Text);
                loanAmount = Convert.ToDouble(txtLA.Text);
               
                R = RI / (12 * 100);

                EMI = Math.Pow(loanAmount * RI * (1 * RI), loanTenure) / Math.Pow((1 + RI), loanTenure);

                txtEmi.Text = Convert.ToString(EMI);


               // MessageBox.Show(" EmpId       \t: " + txtId.Text + " \n Employee Name : " + txtName.Text + "\n Department    : " + Department + "\n Email Id\t : " + txtEmail.Text + "\n Mobile Number : " + txtMob.Text + "\n Gender   \t   : " + "Male" + "\n DOB \t    : " + Dob + "\n Hobbies  \t   :" + Hobbies + "\n EMI : " + EMI);
                MessageBox.Show(" EmpId\t\t: " + txtId.Text + " \n Employee Name\t: " + txtName.Text + "\n Department\t: " + Department + "\n Email Id\t\t: " + txtEmail.Text + "\n Mobile Number\t: " + txtMob.Text + "\n Gender\t\t: " + "Male" + "\n DOB \t\t: " + Dob + "\n Hobbies\t\t: " + Hobbies + "\n EMI\t\t: " + EMI);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("**************" + ex.Message.ToString());
            }
        }

        private void txtLA_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
