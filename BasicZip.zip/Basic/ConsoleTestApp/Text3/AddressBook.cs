﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Text3
{
    class AddressBook
    {
        public static void Main()
        {


            Hashtable AddressDeatails = new Hashtable();


            AddressDeatails.Add(101, new BookDeatails { BookID = 101, BookPrice = 44, BookName = "C++" });
            AddressDeatails.Add(102, new BookDeatails { BookID = 102, BookPrice = 42, BookName = "java" });
            AddressDeatails.Add(103, new BookDeatails { BookID = 103, BookPrice = 200, BookName = "C#" });
            AddressDeatails.Add(104, new BookDeatails { BookID = 104, BookPrice = 260, BookName = "C" });

            do
            {
                int option;

                Console.WriteLine("\n\n------------------------\n");
                Console.WriteLine("  1 : Add BookDeatails");
                Console.WriteLine("  2 : Search book");
                Console.WriteLine("  3 : Display");
                Console.WriteLine("  4 : Exit");
                Console.WriteLine("\n------------------------\n\n");

                Console.WriteLine("Enter the menu option....");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {

                    case 1:
                        FileStream stream = new FileStream("C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data6.txt", FileMode.OpenOrCreate);
                        BinaryFormatter formatter = new BinaryFormatter();

                        formatter.Serialize(stream, AddressDeatails);

                        stream.Close();

                        Console.WriteLine("Book deatails stored....");

                        Console.ReadLine();


                        break;

                    case 2:
                        int searchbookId;
                        Console.WriteLine("\n--------------------------------------------------------------------------");

                        Console.Write("\nEntewr the search book Id : ");
                        searchbookId = Convert.ToInt32(Console.ReadLine());

                        ICollection key = AddressDeatails.Keys;

                        foreach (int k in key)
                        {
                            BookDeatails book = ((BookDeatails)AddressDeatails[k]);

                            FileStream stream1 = new FileStream("C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data4.txt", FileMode.OpenOrCreate);
                            BinaryFormatter formatter1 = new BinaryFormatter();

                            if (searchbookId==book.BookID)
                            {
                                Console.WriteLine("\nBook ID = {0} , Book Price = {1} , Book Name = {2}  ", book.BookID, book.BookPrice, book.BookName);
                            }
                            stream1.Close();

                        }

                        break;

                    case 3:

                        Console.WriteLine("\n--------------------------------------------------------------------------");
                        ICollection key1 = AddressDeatails.Keys;

                        foreach (int k in key1)
                        {
                            BookDeatails book = ((BookDeatails)AddressDeatails[k]);

                            FileStream stream1 = new FileStream("C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data2.txt", FileMode.OpenOrCreate);
                            BinaryFormatter formatter1 = new BinaryFormatter();

                            Console.WriteLine("\nBook ID = {0} , Book Price = {1} , Book Author = {2}  ", book.BookID, book.BookPrice, book.BookName);

                            //book.Display();

                            stream1.Close();

                        }

                        //FileStream stream5 = new FileStream("C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data4.txt", FileMode.OpenOrCreate);
                        //BinaryFormatter formatter5 = new BinaryFormatter();

                        //BookDeatails account = (BookDeatails)formatter5.Deserialize(stream5);
                        //account.Display();

                        //stream5.Close();

                        //FileStream datafile1 = new FileStream("C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data2.txt", FileMode.OpenOrCreate);
                        //int i = 0;
                        //while ((i = datafile1.ReadByte()) != -1)
                        //{
                        //    Console.Write((char)i);
                        //}
                        //datafile1.Close();


                        Console.WriteLine("\n--------------------------------------------------------------------------");
                        Console.ReadLine();
                        break;


                    case 4:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Sorry.!!!   Enter the correct  menu option....");
                        break;
                }
            } while (true);

        }


    }



    [Serializable]

    public class BookDeatails
    {
        public int BookID { get; set; }
        public int BookPrice { get; set; }
        public string BookName { get; set; }

        public BookDeatails()
        {

        }

        public BookDeatails(int bookID, int bookPrice, string bookName)
        {
            BookID = bookID;
            BookPrice = bookPrice;
            BookName = bookName;
        }
        public void Display()
        {
            Console.WriteLine("   " + BookID);
            Console.WriteLine("   " + BookPrice);
            Console.WriteLine("   " + BookName);
        }
    }
}
