﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Text3
{
    class TableCreation
    {

        public static void Main()
        {
            GenerateTable Table1 = new GenerateTable(5);
            Thread Thread1 = new Thread(Table1.ReadNum);
            Thread1.Name = "Thread1";

            GenerateTable Table2 = new GenerateTable(10);
            Thread Thread2 = new Thread(Table2.ReadNum);
            Thread2.Name = "Thread2";

            GenerateTable Table3 = new GenerateTable(15);
            Thread Thread3 = new Thread(Table3.ReadNum);
            Thread3.Name = "Thread3";



            Thread1.Start();
            Thread2.Start();
            Thread3.Start();

            Console.ReadKey();
        }

    }

    class Table
    {
        public void CreateTable(int n)
        {
            lock (this)
            {
                for (int values = 1; values <= 10; values++)
                {
                    Thread.Sleep(300);
                    Console.WriteLine("{0} X {1} = {2}", n, values, n * values);
                }
            }

        }
    }

    class GenerateTable
    {
        Table t;
        int n;

        public GenerateTable(int number)
        {
             n = number;
        }
        public void ReadNum()
        {
           t = new Table();
            t.CreateTable(n);
        }
    }
}


