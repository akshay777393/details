﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Text3
{
    //class GenerateTable
    //{
        
    //    public static void Main()
    //    {


    //        Table t = new Table(5);
    //        Table t1 = new Table(10);
    //        Table t2 = new Table(15);

    //        Thread thread1 = new Thread(t.CreateTable);
    //        thread1.Start();

    //        Thread thread2 = new Thread(t1.CreateTable);
    //        thread2.Start();

    //        Thread thread3 = new Thread(t2.CreateTable);
    //        thread3.Start();

    //        Console.ReadKey();


    //    }
    //}

    //class Table
    //{
    //    int n;

    //    public Table(int number)
    //    {
    //        n = number;
    //    }

    //    public void CreateTable()
    //    {
    
    //        lock (this)
    //        {
    //            for (int mul = 1; mul <= 10; mul++)
    //            {
    //                Thread.Sleep(50);
    //                Console.WriteLine(" {0} X {1} = {2}", mul, n, (mul * n));
    //            }
    //        }
    //    }
    //}
}
