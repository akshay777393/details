﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryDemo
{
    public class Calculater
    {

        public static void display()
        {
            Console.WriteLine("\nI am in DLL project");
            Console.ReadKey();

        }

    }
}
