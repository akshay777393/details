﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{

    enum userType
    {
        retail=1,
        wholesale
    };

    class CustomerDetails
    {

        public static void Main()
        {
            int NoOfcustomer;

            Console.Write("Enter the number of Customer : ");
            NoOfcustomer = Convert.ToInt32(Console.ReadLine());

            Customer[] obj1 = new Customer[NoOfcustomer];


            Console.WriteLine("\n");
            Console.WriteLine("Enter the Customer deatails ");

            for (int i = 0; i < obj1.Length; i++)
            {
                Console.WriteLine("\n\nEnter the Customer {0} deatails", (i + 1));
                Console.WriteLine("********************************");
                obj1[i] = new Customer();
                obj1[i].ReadCustomers();
            }

            Console.WriteLine("\nCustomer deatails");
            Console.WriteLine("*****************\n");

            for (int i = 0; i < obj1.Length; i++)
            {
                Console.WriteLine("-------------------------------\n");
                obj1[i].DisplayCustomer();
                Console.WriteLine("-------------------------------\n");
            }

            Console.ReadKey();
        }

    }
    class Customer
    {
        private int customerID;
        private string customerName;
        int typeUser;

        public int CustomerID
        {
            get { return customerID; }
            set { customerID = value; }
        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        //public int TypeUser
        //{
        //    get { return typeUser; }
        //    set
        //    {
        //        if (typeUser == 1)
        //        {
        //            typeUser = value;
        //        }
        //        else
        //        {
        //            typeUser = value;
        //        }
        //    }
        //}
        

        public void ReadCustomers()
        {
            Console.Write("Enter Customer ID    : ");
            customerID = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Customer Name  : ");
            customerName = Console.ReadLine();

            Console.Write("Enter User Type (1-Retail , 2-Wholesale) : ");
            typeUser = Convert.ToInt32(Console.ReadLine());
        }


        public void DisplayCustomer()
        {
            Console.WriteLine("\nCustomer ID      : " + customerID);
            Console.WriteLine("Customer Name    : " + customerName);
            Console.WriteLine("Customer Type    : " + Enum.GetName(typeof(userType),typeUser));
        }
    }

  
}

