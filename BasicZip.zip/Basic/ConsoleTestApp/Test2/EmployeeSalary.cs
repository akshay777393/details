﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{
    class EmployeeSalary
    {
        public static void Main()
        {
            Employee1 objEmployee = new Employee1();
           // Employee1 objEmployee1 = new Employee1();
            //Employee1 objEmployee2 = new Employee1();
            int option;
            // int number = objEmployee.ReadData();
            int number = objEmployee.noOfEmployees;

            do
            {
                Console.WriteLine("\n\n---------------------------------------");
                Console.WriteLine("1 : Read the Employee Details");
                Console.WriteLine("2 : Display all Employee Details");
                Console.WriteLine("3 : Particular employee details");
                Console.WriteLine("4 : Exit");
                Console.WriteLine("---------------------------------------\n\n");

                Console.Write("\nEnter the Option : ");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        for (int index = 0; index < number; index++)
                        {
                            Console.Write("Enter the Salary : ");
                            objEmployee[index] = Convert.ToInt32(Console.ReadLine());
                        }
                        break;

                    case 2:
                        for (int index = 0; index < number; index++)
                        {
                            Console.Write("\nSalary of Employee {0} : {1}", index + 1, objEmployee[index]);
                        }
                        break;
                        
                    case 3:
                        int indexer;
                        Console.Write("\nEnter the Index of the particular Employee : ");
                        indexer = Convert.ToInt16(Console.ReadLine());
                        Console.Write("Salary : " + objEmployee[indexer]);
                        break;

                    case 4:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid operation");
                        break;
                }
            } while (true);
        }
    }



    class Employee1
    {
        public int noOfEmployees;
        public int[] salary;

        public Employee1()
        {
            Console.WriteLine("Enter the No Of Employees ");
            noOfEmployees = Convert.ToInt32(Console.ReadLine());
            salary = new int[noOfEmployees]; 
        }

        //public int ReadData()
        //{
        //    Console.WriteLine("Enter the No Of Employees ");
        //    noOfEmployees = Convert.ToInt32(Console.ReadLine());
        //    salary = new int[noOfEmployees];

        //    return noOfEmployees;
        //}

        public int this[int index]
        {
            get { return salary[index]; }
            set { salary[index] = value; }
        }
    }
}
