﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{
    class Employee
    {

        public static void Main()
        {
            int noOfEmployee;


           // int emp;
            Console.Write("Enter the number of employee : ");
            noOfEmployee = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n");

            Emp[] obj1 = new Emp[noOfEmployee];


            bool flag = true;

            do
            {
                int menu;

                Console.WriteLine("\n\n---------------------------------------");
                Console.WriteLine("1 : Read the Employee Details");
                Console.WriteLine("2 : Display All Employee Details");
                Console.WriteLine("3 : Particular employee details");
                Console.WriteLine("4 : Exit");
                Console.WriteLine("---------------------------------------\n\n");

                Console.WriteLine("Enter the menu option....");
                menu = Convert.ToInt32(Console.ReadLine());
                switch (menu)
                {

                    case 1:
                        Console.WriteLine("\n\nEnter the Employee deatails");
                        Console.WriteLine("******************************");
                        for (int i = 0; i < obj1.Length; i++)
                        {
                            obj1[i] = new Emp();
                            obj1[i].reademployee();
                        }

                        break;


                    case 2:

                        Console.WriteLine("\n Employee deatails");
                        Console.WriteLine("*********************\n");
                        for (int i = 0; i < obj1.Length; i++)
                        {
                            obj1[i].Display();
                        }
                        break;


                    case 3:
                        int value;
                        Console.WriteLine("\n Enter the employee poshition");
                        value = Convert.ToInt32(Console.ReadLine());
                        
                        //Console.WriteLine("*********************\n");
                        for (int i = 0; i < obj1.Length; i++)
                        {
                            if(obj1[i] == obj1[value-1])
                            {
                                obj1[i].Display();
                            } 
                        }
                        break;


                    case 4:
                        break;

                    default:
                        Console.WriteLine("Sorry.!!!   Enter the correct  menu option....");
                        break;
                }
            } while (flag);
        }


    }
    class Emp
    {

        //static int noOfStudent = 10;

        //public int[] emp = new int[noOfStudent];

        //public int[] values = new int[10];

        //public int this[int index]
        //{
        //    get { return mark[index]; }
        //    set { mark[index] = value; }
        //}



        int id;
        string name;
        int Salary;
        public Emp()
        {

        }
        public Emp(int id, string name, int basicSalary)
        {
            this.id = id;
            this.name = name;
            this.Salary = basicSalary;
        }

        public void reademployee()
        {
            Console.Write("\nEnter the Employee ID   : ");
            id = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the Employee Name : ");
            name = Console.ReadLine();

            Console.Write("Enter the Basic Salary  : ");
            Salary = Convert.ToInt32(Console.ReadLine());
        }

        public void Display()
        {
            Console.WriteLine("\nEmployee ID     : " + id);
            Console.WriteLine("Employee Name   : " + name);
            Console.WriteLine("Employee Salary : " + Salary);
        }




    }








    //class InderesDemo
    //{
    //    public static void Main()
    //    {
    //        Marks marks = new Marks();

    //        marks[0] = 100;

    //        for (int i = 1; i < 10; i++)
    //        {
    //            marks[i] = marks[i - 1] + 10;
    //        }

    //        for (int i = 0; i < 10; i++)
    //        {
    //            Console.WriteLine("Marks of sub {0} = " + marks[i] + "   ", i + 1);
    //        }

    //        Console.ReadKey();

    //    }
    //}
    //class Marks
    //{
    //    static int noOfStudent = 10;
    //    public int[] mark = new int[noOfStudent];

    //    public int[] values = new int[10];

    //    public int this[int index]
    //    {
    //        get { return mark[index]; }
    //        set { mark[index] = value; }
    //    }
    //}





}

