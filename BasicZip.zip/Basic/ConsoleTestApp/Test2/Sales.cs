﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{
    class Sales
    {
        int[] sale;
        int month;
        int[] sortSale;


        public void ReadData()
        {

            Console.Write("Enter the Number of month  : ");
            month = Convert.ToInt32(Console.ReadLine());            

            sale = new int[month];

            Console.WriteLine("\n\n");
            //int value;


            for (int i = 0; i < sale.Length; i++)
            {
                Console.Write("Enter the sales of month {0}   : ", i + 1);
                bool flag = true;
                do
                {
                    try
                    {
                        sale[i] = Convert.ToInt32(Console.ReadLine());
                        flag = false;
                    }
                    catch
                    {
                        Console.WriteLine("\nWrong value........!");
                        Console.Write("Enter valid sales of month {0} : ", i + 1);

                    }
                } while (flag);

            }
        }

        public void sort()
        {
            int temp;
            sortSale = new int[month];
            //sortArray[]= sale[];

            for (int i = 0; i < sale.Length; i++)
            {
                sortSale[i] = sale[i];
            }


            for (int i = 0; i < sortSale.Length-1; i++)
            {
                for (int j = i + 1; j < sortSale.Length-1; j++)
                {
                    if (sortSale[i] > sortSale[j])
                    {
                        temp = sortSale[j];
                        sortSale[j] = sortSale[i];
                        sortSale[i] = temp;
                    }

                }
            }
        }


        public void DisplaySales()
        {
            Console.WriteLine("\n The sales in an mouth with a sorted order : \n");

            foreach (int i in sortSale)
            {
                Console.Write("   " + i);
            }
        }

        public static void Main()
        {
            Sales obj1 = new Sales();
            obj1.ReadData();
            obj1.sort();
            obj1.DisplaySales();

            Console.ReadKey();
        }
    }
}
