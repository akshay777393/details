﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2
{
    class indexer
    {
        public static void Main()
        {
            Markss marks = new Markss();
            Markss values = new Markss();
            marks[0] = 100;

            for (int i = 1; i < 3; i++)
            {
                Console.Write("\nEnter the Customer ID   : ");
                marks[i] = Convert.ToInt32(Console.ReadLine());
                Console.Write("\nEnter the .................   : ");
                values[i] = Convert.ToInt32(Console.ReadLine());
            }
               


            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Marks of sub {0} = " + marks[i] + "   ", i + 1);
                Console.WriteLine("Marks of sub {0} = " + values[i] + "   ", i + 1);
            }

            Console.ReadKey();

        }
    }
    class Markss
    {
        static int noOfStudent = 10;
        public int[] mark = new int[noOfStudent];

        public int[] values = new int[10];

        public int this[int index]
        {
            get { return mark[index]; }
            set { mark[index] = value; }
        }

        //public int this[int index]
        //{
        //    get { return values[index]; }
        //    set { values[index] = value; }
        //}
    }
}
