﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleTestApp.StreamDemo
{
    class FileSteamDemo
    {
        public static void Main()
        {
            FileStream datafile = new FileStream("C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data1.txt", FileMode.OpenOrCreate);
            for(int ii=65;ii<=90;ii++)
            {
                datafile.WriteByte((byte)ii);
            }
            datafile.Close();
      
            Console.WriteLine("File is created");

            //-----------------------------------------------------------------

            Console.WriteLine("File Read opration.....");

            FileStream datafile1 = new FileStream("C:\\Users\\1028260\\Desktop\\AJMAL\\ABCD\\data1.txt", FileMode.OpenOrCreate);
            int i = 0;
            while((i=datafile1.ReadByte())!=-1)
            {
                Console.Write((char)i);
            }
            datafile1.Close();



            Console.ReadLine();
        }
    }
}
