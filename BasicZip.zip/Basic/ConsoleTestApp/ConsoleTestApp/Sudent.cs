﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Sudent
    {

        int id;
        double Mark1; // TotalMark;
        string name;
        string result;


        static int MaxMark=100, MinMark=0, PassMark=40;

        public void ReadData()
        {
            bool flag = false;

            Console.WriteLine("\nEnter the id   : ");
            id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nEnter the Name : ");
            name = Console.ReadLine();
           
            flag = false;
            do
            {

                Console.WriteLine("\nEnter the Mark : ");
                Mark1 = Convert.ToInt32(Console.ReadLine());

                
            
                if(Mark1<MinMark || Mark1>MaxMark)
                {
                    flag = true;
                    Console.WriteLine("\nSorry..........Enter the  correct Mark ");  
                }
                
                    

            } while (flag);

            if (Mark1>=PassMark)
            {
                result = "Passed";
            }
            else
            {
                result = "Failed";
            }
        }

        public void Display()
        {

            Console.WriteLine("---------------------------");

            Console.WriteLine("\nId : " + id);
            Console.WriteLine("\nName : " + name);
            Console.WriteLine("\nMark : " + Mark1);
            Console.WriteLine("\nResult : " + result);

            Console.WriteLine("---------------------------");

        }

        public static void Main()
        {
            Sudent Obj1 = new Sudent();
            Obj1.ReadData();
            Obj1.Display();

            Console.ReadKey();        }

    }
}
