﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryDemo;

namespace ConsoleTestApp
{
    class TestLibarry
    {

        public static void Main()
        {
            Calculater.display();
            Console.ReadLine();
        }
    }
}
