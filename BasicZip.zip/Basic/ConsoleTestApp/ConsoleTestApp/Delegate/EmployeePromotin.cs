﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegate
{
    class EmployeePromotin
    {
        public static void Main()
        {
            List<Employee> employeeList = new List<Employee>();

            employeeList.Add(new Employee { ID = 101, Name = "Gopu", Salary = 6000, Experance = 4 });
            employeeList.Add(new Employee { ID = 102, Name = "Shasna", Salary = 4000, Experance = 5 });
            employeeList.Add(new Employee { ID = 103, Name = "Aiswarya", Salary = 4000, Experance =6 });
            employeeList.Add(new Employee { ID = 104, Name = "Gopu1", Salary = 4000, Experance = 3 });
            employeeList.Add(new Employee { ID = 105, Name = "Gopu2", Salary = 4000, Experance = 7 });
            employeeList.Add(new Employee { ID = 106, Name = "Gopu3", Salary = 6000, Experance = 5 });
            employeeList.Add(new Employee { ID = 107, Name = "Gopu5", Salary = 8000, Experance = 4 });

            Console.WriteLine("list of Employee eligable for promotion");
            Employee.GetPromotedList(employeeList);

            Console.ReadLine();
        }
    }

    class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Experance { get; set; }
        public int Salary { get; set; }

        public static void GetPromotedList(List<Employee> employees)
        {
            foreach(Employee employee in employees)
            {
                if(employee.Experance>=5)
                {
                    Console.WriteLine("\nEmployee id        {0}", employee.ID);
                    Console.WriteLine("Employee Name      {0}", employee.Name);
                    Console.WriteLine("Employee Experance {0}", employee.Experance);
                    Console.WriteLine("Employee Salary    {0}", employee.Salary);
                    Console.WriteLine("*********************************");
                }
            }
        }

    }
}
