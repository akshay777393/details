﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegate
{

    public delegate void Calcute(int val1, int val2);

    class DelegateSample
    {
        public static void Main()
        {
            Calculator calculate1 = new Calculator();

            Calcute calculate = new Calcute(Calculator.sum);

            //calculate(10, 20);

            calculate += Calculator2.sub;
            calculate += calculate1.Mul;
            calculate(10, 20);

            Console.ReadLine();
        }

    }

    class Calculator
    {
        public static void sum(int value1, int value2)
        {
            Console.WriteLine(value1 + value2);
        }

        public void Mul(int value1, int value2)
        {
            Console.WriteLine(value1 * value2);
        }


    }
    class Calculator2
    {
        public static void sub(int value1, int value2)
        {
            Console.WriteLine(value1 - value2);
        }

    }
}
