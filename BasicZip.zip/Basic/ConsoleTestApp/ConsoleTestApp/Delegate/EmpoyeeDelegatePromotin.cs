﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegate
{

    public delegate bool IspromotableDelegate(EmployeeDetails employee);

    class EmpoyeeDelegatePromotin
    {
        public static void Main()
        {
            List<EmployeeDetails> employeeList = new List<EmployeeDetails>();

            employeeList.Add(new EmployeeDetails { ID = 101, Name = "Gopu", Salary = 6000, Experance = 4 });
            employeeList.Add(new EmployeeDetails { ID = 102, Name = "Shasna", Salary = 4000, Experance = 5 });
            employeeList.Add(new EmployeeDetails { ID = 103, Name = "Aiswarya", Salary = 4000, Experance = 6 });
            employeeList.Add(new EmployeeDetails { ID = 104, Name = "Gopu1", Salary = 4000, Experance = 3 });
            employeeList.Add(new EmployeeDetails { ID = 105, Name = "Gopu2", Salary = 4000, Experance = 7 });
            employeeList.Add(new EmployeeDetails { ID = 105, Name = "Gopu3", Salary = 4000, Experance = 4 });
            employeeList.Add(new EmployeeDetails { ID = 106, Name = "Gopu4", Salary = 2000, Experance = 5 });
            employeeList.Add(new EmployeeDetails { ID = 107, Name = "Gopu5", Salary = 8000, Experance = 4 });

            IspromotableDelegate ispromotableDelegate = new IspromotableDelegate(Ispromotable);

            Console.WriteLine("list of Employee eligable for promotion");

            EmployeeDetails.GetPromotedList(employeeList,ispromotableDelegate);

            Console.ReadLine();
        }

        public static bool Ispromotable(EmployeeDetails employee)
        {
            bool eligable = false;
            if(employee.Experance>=5 && employee.Salary<5000)
            {
                eligable = true;
            }
            return eligable;
        }
    }

    public class EmployeeDetails
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Experance { get; set; }
        public int Salary { get; set; }



        //public static void GetPromotedList(List<EmployeeDetails> employees)
        //{
        //    foreach (EmployeeDetails employee in employees)
        //    {
        //        if (employee.Experance >= 5)
        //        {
        //            Console.WriteLine("\nEmployee id        : {0}", employee.ID);
        //            Console.WriteLine("Employee Name      : {0}", employee.Name);
        //            Console.WriteLine("Employee Experance : {0}", employee.Experance);
        //            Console.WriteLine("Employee Salary    : {0}", employee.Salary);
        //            Console.WriteLine("*********************************");
        //        }
        //    }
        //}


        public static void GetPromotedList(List<EmployeeDetails> employees,IspromotableDelegate ispromotableDelregate)
        {
            foreach (EmployeeDetails employee in employees)
            {
                if (ispromotableDelregate(employee))
                {
                    Console.WriteLine("\nEmployee id        : {0}", employee.ID);
                    Console.WriteLine("Employee Name      : {0}", employee.Name);
                    Console.WriteLine("Employee Experance : {0}", employee.Experance);
                    Console.WriteLine("Employee Salary    : {0}", employee.Salary);
                    Console.WriteLine("*********************************");
                }
            }
        }

    }
}
