﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegate
{
    public delegate void Print1(int value);

    class AnonymousMethod2                              //a method withiut name
    {


        public static void Main()
        {
            PrintHelperMethod(delegate (int val) { Console.WriteLine("AnonymousMethod method : {0}", val); }, 100);

            Console.ReadLine();
        }

            public static void PrintHelperMethod(Print1 printDel, int val )
            {
                val += 10;
                printDel(val);
            }
          

        
    }
}
