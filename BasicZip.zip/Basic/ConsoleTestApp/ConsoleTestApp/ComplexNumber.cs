﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ComplexNumber
    {
        int real, imaginary;


        public ComplexNumber()
        {
            
        }



        public ComplexNumber(int real, int imaginary)
        {
            this.real = real;
            this.imaginary = imaginary;
        }



        public void DisplayNumber()
        {
            Console.WriteLine("\n\t Real : {0} Imaginary : {1}", real, imaginary);
            Console.WriteLine("\n\t Ruselt = {0}+{1}i", real, imaginary);
        }

        public void ReadComplexNumber()
        {
            Console.WriteLine("Enter the value of real part :");
            real = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the value of imagunary part :");
            imaginary = Convert.ToInt32(Console.ReadLine());

        }

        public static ComplexNumber operator +(ComplexNumber d1, ComplexNumber d2)
        {
            ComplexNumber d = new ComplexNumber();

            d.real = d1.real + d2.real;
            d.imaginary = d1.imaginary + d2.imaginary;
       
            return d;
        }


        public static void Main()
        {
            ComplexNumber cplx1 = new ComplexNumber();
            ComplexNumber cplx2 = new ComplexNumber();
            ComplexNumber cplx3 = new ComplexNumber();
            

            Console.WriteLine("\nEnter the value of complex 1");
            Console.WriteLine("-------------------------------");
            cplx1.ReadComplexNumber();

            Console.WriteLine("\nEnter the value of complex 2");
            Console.WriteLine("-------------------------------");
            cplx2.ReadComplexNumber();

            cplx3 = cplx1 + cplx2;
            Console.WriteLine("\n_______Addition_of_complex_Number______");
            cplx3.DisplayNumber();


            Console.ReadKey();

        }

    }
}
