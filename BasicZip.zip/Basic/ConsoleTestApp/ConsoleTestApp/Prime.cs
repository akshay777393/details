﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Prime
    {
        int value;
        string result;

        public void ReadData()
        {
            Console.WriteLine("\n\nEnter the value : ");
            value = Convert.ToInt32(Console.ReadLine());
        }
        public void Find()
        {
                bool flag = true;

                for(int no = 2; no<value; no++)
                {
                    if(value%no==0)
                    {
                        flag=false;
                        break;
                    }
                }
                if (flag)
                {
                    result = "PRIME";
                }
                else
                {
                result = "NOT PRIME";
                }    
        }

        public void display()
        {
                Console.WriteLine("The given number {0} is {1} number",value,result);
        }

        public static void Main(string[] args)
        {

            //for (int i = 0; i<=5 ; i++)
           // {
                Prime obj1 = new Prime();
                obj1.ReadData();
                obj1.Find();
                obj1.display();

                

                Console.ReadKey();
            //}
          
        }

    }
}
