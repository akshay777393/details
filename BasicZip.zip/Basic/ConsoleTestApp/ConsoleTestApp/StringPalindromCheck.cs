﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StringPalindromCheck
    {


    }

    class Palindrome
    {
        string word,reves;
        char[] charword;
        char[] wordRev;


        public void readString()
        {
            Console.Write("\nEnter the String : ");
            word = Console.ReadLine();

            charword = new char[word.Length];
            wordRev = new char[word.Length];
        }

        public void CheckPalindrome()
        {
           // char temp;
            int chr= word.Length;

            for (int i = 0; i < word.Length; i++)
            {
                charword[i] = word[chr];
                chr--;

            }


            //for (int i = 0; i < word.Length; i++)
            //{
            //    reves[i] = charword[i];
            //}
            //if ()
            //{

            //}
        }

    }
}
