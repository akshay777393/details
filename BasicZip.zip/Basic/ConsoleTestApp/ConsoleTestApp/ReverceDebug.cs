﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ReverceDebug
    {

        int value1 , reverce = 0;

        public void ReadData()
        {
            Console.WriteLine("\n Enter the value : ");
            value1 = Convert.ToInt32(Console.ReadLine());

        }
        public void findreverce()
        {
            int num = value1;
            do
            {

                int k = num % 10;
                num = num / 10;
                reverce = (reverce * 10) + k;

            } while (num > 0);
        }

        public void display()
        {
            Console.WriteLine("The reverce of {0} is {1}", value1, reverce);
        }
        public static void Main()
        {
            Reverce Objdigit1 = new Reverce();
            Objdigit1.ReadData();
            Objdigit1.findreverce();
            Objdigit1.display();

            Console.ReadKey();
        }
    }
}
