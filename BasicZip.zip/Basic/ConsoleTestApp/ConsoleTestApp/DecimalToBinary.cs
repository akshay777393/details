﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DecimalToBinary
    {

        int Binary=0, Decimal;

        public void ReadData()
        {
            Console.WriteLine("\n\nEnter the Decimal value : ");
            Decimal = Convert.ToInt32(Console.ReadLine());
        }

        public void Convertion()
        {
            int num, rem,i= 1;

            num = Decimal;

            while (num > 0)
            {
                rem = num % 2;
                Binary = Binary +(i*rem);
                num /= 2;
                i=i*10;
            }
        }

        public void display()
        {

            Console.WriteLine("\n\nBinary = {0} \nDecimal number = {1} ", Decimal,Binary );

        }

        public static void Main()
        {
            DecimalToBinary Obj1 = new DecimalToBinary();
            Obj1.ReadData();
            Obj1.Convertion();
            Obj1.display();


            Console.ReadKey();

        }

    }
}
