﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Eoro
    {

        int value1,k;
       // String=k2;

        public void ReadData()
        {
            Console.WriteLine("Enter the value1 : ");
            value1 = Convert.ToInt32(Console.ReadLine());
            
        }
        public void findevenorodd()
        {
            k = value1 % 2;

            //value1 = Convert.ToString();

            if (k==1)
            {
                Console.WriteLine("it is an odd number");
            }
            else
            {
                Console.WriteLine("it is an even number");
            }
        }

        public static void Main(string[] args)
        {
            Eoro obj1 = new Eoro();
            obj1.ReadData();
            obj1.findevenorodd();

            Console.ReadKey();
        }

    }
}
