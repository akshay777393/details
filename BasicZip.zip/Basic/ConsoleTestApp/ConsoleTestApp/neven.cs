﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class neven
    {
        int value1, i, sum=0;

        public void ReadData()
        {
            Console.WriteLine("Enter the value1 : ");
            value1 = Convert.ToInt32(Console.ReadLine());

        }


        public void Findsumeven()
        {
            Console.WriteLine("\nSum of Even number's are : ");
            for (i = 2; i <= value1; i=i+2)
            {
                    sum = sum + i;

            }

            Console.WriteLine(sum);
        }

        public static void Main(string[] args)
        {
            neven obj1 = new neven();
            obj1.ReadData();
            obj1.Findsumeven();

            Console.ReadKey();
        }



    }
}
