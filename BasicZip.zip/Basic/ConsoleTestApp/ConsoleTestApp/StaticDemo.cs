﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StaticDemo
    {
        public static void Main()
        {
            Console.WriteLine("20 + 10 =" + Calculate.sum(10, 20));

            Calculate obj1 = new Calculate();
            Console.WriteLine("50 - 30 =" + obj1.diff(50, 30));

            Console.ReadKey();
       
        }

    }
}
