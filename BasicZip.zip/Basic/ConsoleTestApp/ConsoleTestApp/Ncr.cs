﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Ncr
    {
        int n, r;
        int ncr;

        public Ncr(int n,int r)
        {
            this.n = n;
            this.r = r;
        }

        public static int fatorial(int num)
        {
            int fact=1;
            for(int i=1;i<=num;i++)
            {
                fact =fact * i;
            }
            return fact;
        }

        public void FindNcr()
        {
            ncr = fatorial(n)/((fatorial(r) * (fatorial(n - r))));
        }

        public void Display()
        {
            Console.WriteLine("n:{0}, r:{1} , ncr : {2}", n, r, ncr);
        }

        public static void Main()
        {
            Ncr obj1 = new Ncr(5, 3);
            obj1.FindNcr();
            obj1.Display();

            Console.ReadKey();
        }
            

    }
}
