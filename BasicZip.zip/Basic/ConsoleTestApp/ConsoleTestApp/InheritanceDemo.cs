﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InheritanceDemo
    {

        public static void Main()
        {
            A obja = new A();
            B objb = new B();
            obja.displayA();
            objb.displayb();

            Console.ReadKey();

        }
    }

    class A
    {
        public int val1;

        public A()
        {
            val1 = 10;
        }

        public void displayA()
        {
            Console.WriteLine("I am in base class A val1 : " + val1);
        }
        public virtual void display()
        {
            Console.WriteLine("I am in base class A " + val1);
        }
    }

    class B : A
    {
        int val2;

         public B()
        {
            val2 = 100;
        }

        public override void display()
        {
            Console.WriteLine("I am in base class A " + val1);
        }
        public void displayb()
        {
            Console.WriteLine("I am in base class B val2 : " + val2);
            Console.WriteLine("I am in base class B val1 : " + val1);
            //Console.Write("I am in base class A val1 : " + val1);
        }
    }

}
