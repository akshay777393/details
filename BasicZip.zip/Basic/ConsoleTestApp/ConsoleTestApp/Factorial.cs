﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Factorial
    {
        int value,fact=1;

        public void ReadData()
        {
            Console.WriteLine("Enter the value : ");
            value = Convert.ToInt32(Console.ReadLine());

        }
        public void findfactorial()
        {
            for(int i = 1; i <= value; i++)
            {
                fact *= i;
            }

        }
        public void display()
        {
            Console.WriteLine("The factorial of {0} is {1}", value, fact);

        }


        public static void Main(string[] args)
        {
            Factorial obj1 = new Factorial();
            obj1.ReadData();
            obj1.findfactorial();
            obj1.display();

            Console.ReadKey();
        }


    }
}
