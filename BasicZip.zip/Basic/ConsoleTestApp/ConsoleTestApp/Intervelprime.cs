﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Intervelprime
    {
        int value1,value2;
        public void ReadData()
        {
            Console.WriteLine("\n Enter the first limit : ");
            value1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n Enter the secound limit : ");
            value2 = Convert.ToInt32(Console.ReadLine());

        }


        public Boolean PrimeCheck(int x)
        {
            int y = x;
            Boolean c = true;
            for (int i=2;i<=x/2;i++)
            {
                if(x%i==0)
                {
                    c = false;
                    break;
                }
            }
            return c;
        }

        public void Interval()
        {
            Console.WriteLine("\n The prime number in the intervel of {0} to {1} are : ",value1,value2);
            for(int i = value1; i <= value2; i++)
            {
                if(PrimeCheck(i))
                {
                    Console.WriteLine(i + " ");
                }
            }
        }

        /*
        public void Find()
        {
            for (int no = value1; no < value2; no++)
            {
                bool flag = true;

                for (int i = 2; i < no; i++)
                {
                    if (no % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    Console.WriteLine("\t" + no);
                }

            }

        }*/

        public static void Main()
        {
            Intervelprime Objdigit1 = new Intervelprime();
            Objdigit1.ReadData();
            // Objdigit1.Find();
            Objdigit1.Interval();

            Console.ReadKey();
        }

    }
}
