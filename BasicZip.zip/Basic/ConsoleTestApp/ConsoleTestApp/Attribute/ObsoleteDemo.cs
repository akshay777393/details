﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ConsoleTestApp.Attribute
{
    class ObsoleteDemo
    {
        public static void Main()
        {

            List<int> list = new List<int>();
            list.Add(10);
            list.Add(20);
            list.Add(30);
            list.Add(40);

            int result1 = calculator.Add(30,20);

            int result2 = calculator.Add(list);
//
            Console.WriteLine("Result 1 : " + result1);
            Console.WriteLine("Result 2 : " + result2);

            Console.ReadKey();

        }

    }


    [Obsolete("depricated class")]
    class calculator
    {
        [Obsolete("New method : int Add(List<int> number)")]

        public static int Add(int value1, int value2)
        {
            return (value1 + value2);
        }

        public static int Add(List<int> numbers)
        {
            int sum = 0;
            foreach(int num in numbers)
            {
                sum += num;
            }
            return sum;
        }
   
    }
}
