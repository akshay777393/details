﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Indexers
{
    class InderesDemo
    {
        public static void Main()
        {
            Marks marks  = new Marks();

            marks[0] = 100;

            for(int i = 1; i < 10; i++)
            {
                marks[i] = marks[i-1] + 10;
            }

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Marks of sub {0} = "+marks[i] + "   ",i+1);
            }

            Console.ReadKey();

        }
    }
    class Marks
    {
        static int noOfStudent=10;
        public int[] mark = new int[noOfStudent];

        public int[] values = new int[10];

        public int this [int index]
        {
            get { return mark[index]; }
            set { mark[index] = value; }
        }
    }
}
