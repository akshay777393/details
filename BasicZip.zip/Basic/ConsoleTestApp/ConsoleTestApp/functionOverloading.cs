﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class functionOverloading
    {

        public static void display(int i)
        {
            Console.WriteLine("Display (int i )   : " + i);
        }

        public static void display(int i,int j)
        {
            Console.WriteLine("Display (int i )   : " + i);
            Console.WriteLine("Display (int j )   : " + j);
        }

        public static void display(double i)
        {
            Console.WriteLine("Display (double i) : " + i);
        }

        public static void display(int i, double j)
        {
            Console.WriteLine("Display (int i)    : " + i);
            Console.WriteLine("Display (double i) : " + i);
        }

        public static void Main()
        {
            display(10);
            display(10,7.0);
            display(10.2);
            display(1,34);

            Console.ReadKey();
        }
    }
}
