﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Exception_Demo
{
    class Input
    {
        public static void Main()
        {
            int val;
            Console.WriteLine("Enter a number  :");
            val = ReadI();
            Console.WriteLine("Number :"+val);

            Console.ReadKey();
        }


        public static int ReadI()
        {
            int value = 0;
            bool flag = true;

            do
            {
                try
                {
                    value = Convert.ToInt32(Console.ReadLine());
                    flag = false;
                }
                catch
                {
                    Console.WriteLine("Wrong value | Enter a valid integer ");

                }
            } while (flag);
            return value;
        }
    }
}
