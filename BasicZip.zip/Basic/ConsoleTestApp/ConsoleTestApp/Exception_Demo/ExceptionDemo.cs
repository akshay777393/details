﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Exception_Demo
{
    class ExceptionDemo
    {

        public static void Main()
        {
            int a, b, c;
            a = 10;
            b = 5;
            c = 0;

            Console.WriteLine("Hi I am before cach");

            try
            {
                Console.WriteLine("A : " + a);
                Console.WriteLine("B : " + b);

                c = a / (b - 5);


                Console.WriteLine("C : " + c);
                Console.WriteLine("Hi i caculated without problem");
            }
            catch(Exception e)
            {
                Console.WriteLine("I am the catch error : "+e.Message.ToString());
                c = a / b;
                Console.WriteLine("C : " + c);
            }
            Console.WriteLine("I am in out side of the catch");
            Console.ReadKey();
        }
    }
}
