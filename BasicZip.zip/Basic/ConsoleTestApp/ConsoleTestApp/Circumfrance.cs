﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class circumference
    {

        double radius;//,area, circum;
        const double PI = 3.14;


        public void ReadData()
        {
            Console.WriteLine("\n Enter the radius of circle : ");
            radius = Convert.ToInt32(Console.ReadLine());
        }


        public void Find()
        {


           // area = PI 

            //for (int no = 2; no <= value; no++)
            //{
            //    bool flag = true;

            //    for (int i = 2; i < no; i++)
            //    {
            //        if (no % i == 0)
            //        {
            //            flag = false;
            //            break;
            //        }
            //    }
            //    if (flag)
            //    {
            //        Console.WriteLine("\t" + no);
            //    }
            //}


        }

        public static void Main()
        {
            circumference Objdigit1 = new circumference();
            Objdigit1.ReadData();
            Objdigit1.Find();

            Console.ReadKey();
        }

    }
}
