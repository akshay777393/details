﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Sum
    {
        int value1, value2, value3;

        public void ReadData()
        {
            Console.WriteLine("Enter the value1 : ");
            value1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the value2 : ");
            value2 = Convert.ToInt32(Console.ReadLine());

        }

        public void findsum()
        {
            value3 = value1 + value2;
        }

        public void DisplyData()
        {
            Console.WriteLine("Value1.... : " + value1);
            Console.WriteLine("Value2 : " + value2);
            Console.WriteLine("Value3 : " + value3);
        }

        public static void Main(string[] args)
        {
            Sum obj1 = new Sum();
            obj1.ReadData();
            obj1.findsum();
            obj1.DisplyData();

            Console.ReadKey();
        }

    }
}
