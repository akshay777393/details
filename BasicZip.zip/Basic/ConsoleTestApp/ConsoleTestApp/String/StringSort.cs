﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.String
{
    class StringSort
    {
        string str;
        char[] sort;

        public void readString()
        {
            Console.Write("\nEnter the String : ");
            str = Console.ReadLine();
            sort = new char[str.Length];
        }

        public void sorting()
        {
            char temp;
            for (int i = 0; i < str.Length; i++)
            {
                sort[i] = str[i];
               
            }

            for (int i = 0; i < str.Length; i++)
            {
                for (int j = i + 1; j < str.Length; j++)
                {
                    if (sort[i].CompareTo(sort[j]) >0)
                    {
                        temp = sort[j];
                        sort[j] = sort[i];
                        sort[i] = temp;
                    }

                }
            }
        }

        public void DisplyString()
        {
            Console.WriteLine("\nSorted String");
            Console.WriteLine("------------------------");

            for (int i = 0; i < str.Length; i++)
            {
                Console.Write(sort[i]);
            }
            Console.WriteLine("\n\nUnsorted Array");
            Console.WriteLine("------------------------");
            
            Console.Write(str);
        }



        public static void Main(string[] args)
        {
            StringSort obj1 = new StringSort();
            obj1.readString();
            obj1.sorting();
            obj1.DisplyString();

            Console.ReadKey();
        }

    }
}
