﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeN
    {

        int value;


        public void ReadData()
        {
            Console.WriteLine("\n Enter the limit : ");
            value = Convert.ToInt32(Console.ReadLine());
        }


        public void Find()
        {

            for (int no = 2; no <= value; no++)
            {
                bool flag = true;

                for (int i = 2; i < no; i++)
                {
                    if (no % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    Console.WriteLine("\t" + no);
                }
            }


        }

        public static void Main()
        {
            PrimeN Objdigit1 = new PrimeN();
            Objdigit1.ReadData();
            Objdigit1.Find();

            Console.ReadKey();
        }

    }
}
