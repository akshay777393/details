﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class interval
    {

        int value1, value2,i;

        public void ReadData()
        {
            Console.WriteLine("Enter the value1 : ");
            value1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the value2 : ");
            value2 = Convert.ToInt32(Console.ReadLine());

        }


        public void Findeven()
        {
            Console.WriteLine("\n Even number's are : ");
            for (i= value1;i<=value2;i++)
            {
               
                if (i%2==0)
                {
                    Console.WriteLine("\t"+i);
                }
               
            }
        }



        public void Findodd()
        {
            Console.WriteLine("\n Odd number's are : ");
            for (i = value1; i <= value2; i++)
            {
                if (i % 2 == 1)
                {
                    Console.WriteLine("\t" + i);
                }

            }
        }



        public static void Main(string[] args)
        {
            interval obj1 = new interval();
            obj1.ReadData();
            obj1.Findeven();
            obj1.Findodd();
        
            Console.ReadKey();
        }

    }
}
