﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class CmdRead
    {
        static void Main(string[] args)
        {
            for(int i=0;i<args.Length;i++)
            {
                Console.WriteLine(args[i]);
            }
        }
    }
}
