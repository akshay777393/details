﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class SumOfNumber
    {
        int[] num;
        int n,sum=0;

        public void ReadData()
        {
            Console.WriteLine("Enter the limit n : ");
            n = Convert.ToInt32(Console.ReadLine());               // given a value for array limit

            num = new int[n];                                      // creation the array


            Console.WriteLine("Enter the {0} numbers ",n);
            Console.WriteLine("------------------------");
            for (int i=0;i<num.Length;i++)
            {
                num[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        public void findsum()
        {
            for (int i = 0; i < num.Length; i++)
            {
                sum += num[i]; 
            }
        }

        public void DisplyData()
        {
            Console.WriteLine("\nThe numbers are");
            Console.WriteLine("------------------------");


            foreach (int i in num)
            {
                Console.Write(" "+ i);
            }
            Console.WriteLine("\n\nSUM OF NUMBER = "+sum);

        }

        public static void Main(string[] args)
        {
            SumOfNumber obj1 = new SumOfNumber();
            obj1.ReadData();
            obj1.findsum();
            obj1.DisplyData();

            Console.ReadKey();
        }

    }
}
