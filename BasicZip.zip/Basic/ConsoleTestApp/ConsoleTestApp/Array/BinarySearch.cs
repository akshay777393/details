﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class BinarySearch
    {
        int n;
        int[] num;

        public void ReadData()
        {
            Console.WriteLine("Enter the limit n : ");
            n = Convert.ToInt32(Console.ReadLine());               // given a value for array limit

            num = new int[n];

            Console.WriteLine("------------------------");
            for (int i = 0; i < num.Length; i++)
            {
                num[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        public void sort()
        {
            

            int temp;
            for (int i = 0; i < num.Length; i++)
            {
                for (int j = i + 1; j < num.Length; j++)
                {
                    if (num[i] > num[j])
                    {
                        temp = num[j];
                        num[j] = num[i];
                        num[i] = temp;
                    }

                }
            }

            Console.WriteLine("\nSorted Array");
            Console.WriteLine("\n------------------------\n");

            foreach (int i in num)
            {
                Console.Write(" " + i);
            }


        }

        public void search()
        {
            int high, low, value;
            int mid;

            low = 0;
            high = n - 1;

            Console.Write("\n\nEnter the search value : ");
            value = Convert.ToInt32(Console.ReadLine());

            bool flag = false;

            do
            {
                mid = (low + high) / 2;
                if (value == num[mid])
                {
                    flag = true;
                    break;
                }
                else if (value > num[mid])
                {
                    low = mid + 1;
                }
                else
                {
                    high = mid - 1;
                }
            } while (low <= high);


            if (flag)
            {
                Console.WriteLine("\nThe number {0} is found", value);
            }
            else
            {
                Console.WriteLine("\nThe number {0} is not found", value);
            }

        }

        public void DisplyData()
        {
            Console.WriteLine("\n Array");
            Console.WriteLine("\n------------------------\n");

            foreach (int i in num)
            {
                Console.Write(" " + i);
            }
        }

        public static void Main(string[] args)
        {
            BinarySearch obj1 = new BinarySearch();
            obj1.ReadData();
            obj1.sort();
            obj1.search();
          //  obj1.DisplyData();

            Console.ReadKey();
        }

    }
}
