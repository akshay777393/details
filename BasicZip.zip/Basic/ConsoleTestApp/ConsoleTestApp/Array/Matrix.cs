﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class Matrix
    {
        int row, col;
        int[,] num;

        public Matrix(int row,int col)
        {
            this.row=row;
            this.col=col;
            num = new int[row,col];
        }


        public Matrix()
        {
            
        }


        public void ReadMatrix()
        {
            Console.Write("\n Enter the row  : ");
            row = Convert.ToInt32(Console.ReadLine());

            Console.Write("\n Enter the col  : ");
            col = Convert.ToInt32(Console.ReadLine());

            num = new int[row, col];

            Console.WriteLine("\n\nEnter the elment of matrix");
            Console.WriteLine("------------------------");
            for (int i = 0; i <row; i++)
            {
                for (int j = 0; j <col; j++)
                {
                    num[i,j] = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("----------------------------");
            }
        }

        public void DisplayMatrix()
        {

            Console.WriteLine("\n\n");
            
            for (int i = 0; i <row; i++)
            {
                for (int j = 0; j <col; j++)
                {
                    Console.Write("  " + num[i, j]);
                }
                Console.WriteLine("\n");
            }
        }

        public void AddMatrix(Matrix objMatrix1, Matrix objMatrix2)
        {
            if(objMatrix1.row!=objMatrix2.row || objMatrix1.col != objMatrix2.col)
            {
                Console.WriteLine("\n Sorry !!!  Different dimension matrix cannot able to addition ");
            }
            else
            {
                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < col; j++)
                    {
                        num[i, j] = objMatrix1.num[i, j] + objMatrix2.num[i, j];
                    }
                }
            }
           
        }

        public void SubMatrix(Matrix objMatrix1, Matrix objMatrix2)
        {
            if (objMatrix1.row != objMatrix2.row || objMatrix1.col != objMatrix2.col)
            {
                Console.WriteLine("\n Sorry !!!  Different dimension matrix cannot able to subtraction ");
            }
            else
            {
                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < col; j++)
                    {
                        num[i, j] = objMatrix1.num[i, j] - objMatrix2.num[i, j];
                    }
                }
            }

        }

        public static void Main()
        {
            Matrix obj1 = new Matrix();
            obj1.ReadMatrix();
            obj1.DisplayMatrix();

            Matrix obj2 = new Matrix();
            obj2.ReadMatrix();
            obj2.DisplayMatrix();

            Matrix obj3 = new Matrix(obj1.row,obj1.col);                                      //to difine the row & colum obj3


            Console.WriteLine("\n------------MATRIX ADDITION----------");
            obj3.AddMatrix(obj1, obj2);
            obj3.DisplayMatrix();

            Matrix obj4 = new Matrix(obj1.row, obj1.col);                                    //to difine the row & colum obj4

            Console.WriteLine("\n------------MATRIX SUBTRACTION----------");
            obj4.SubMatrix(obj1, obj2);
            obj4.DisplayMatrix();

            Console.ReadKey();
        }

    }
}
