﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class ArrayOfObject
    {
        public static void Main()
        {
            Student[] obj1 = new Student[3];

            Console.WriteLine("Enter the student deatails ");


            for (int i = 0; i < obj1.Length; i++)
            {
                Console.WriteLine("Enter the student {0} deatails ",(i+1));
                Console.WriteLine("******************************");
                obj1[i] = new Student();
                obj1[i].readStudent();

            }

            Console.WriteLine("\nStudent deatails");
            Console.WriteLine("*****************");

            for (int i = 0; i < obj1.Length; i++)
            {
                Console.WriteLine(obj1[i]);
            }

            Console.ReadKey();
        }
       

    }

    class Student
    {
        int id;
        string name;

        public Student()
        {

        }
        public Student(int id ,string name)
        {
            this.id = id;
            this.name = name;
        }
        
        public void readStudent()
        {
            Console.WriteLine("Enter the Student ID   : ");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Student Name : ");
            name = Console.ReadLine();
        }

        public override string ToString()
        {
            string output;

            output = "-------------------------------\n";
            output += "Student ID : " + id + "\n";
            output += "Name       : " + name + "\n";
            output += "_______________________________\n";

            return output;
        }

    }
}
