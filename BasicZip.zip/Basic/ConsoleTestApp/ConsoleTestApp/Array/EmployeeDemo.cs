﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class EmployeeDemo
    {
        public static void Main()
        {
            int emp;
            Console.Write("Enter the number of employee : ");
            emp = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n");

            Employee[] obj1 = new Employee[emp];

            Console.WriteLine("Enter the Employee deatails ");

            for (int i = 0; i < obj1.Length; i++)
            {
                Console.WriteLine("\n\nEnter the Employee {0} deatails", (i + 1));
                Console.WriteLine("******************************");
                obj1[i] = new Employee();
                obj1[i].reademployee();
                obj1[i].Find();

            }

            Console.WriteLine("\nEmployee deatails");
            Console.WriteLine("*****************");

            for (int i = 0; i < obj1.Length; i++)
            {
                Console.WriteLine(obj1[i]);
            }

            Console.ReadKey();
        }
    }

    class Employee
    {


        int id;
        string name;
        int basicSalary;

        double HRA, TA, DA;

        public Employee()
        {

        }
        public Employee(int id, string name, int basicSalary)
        {
            this.id = id;
            this.name = name;
            this.basicSalary = basicSalary;
        }

        public void reademployee()
        {
            Console.Write("Enter the Employee ID   : ");
            id = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the Employee Name : ");
            name = Console.ReadLine();

            Console.Write("Enter the Basic Salary  : ");
            basicSalary = Convert.ToInt32(Console.ReadLine());
        }

        public void Find()
        {
            HRA =(basicSalary * 20)/ 100;
            TA = (basicSalary * 15) / 100;
            DA = (basicSalary * 70) / 100;
        }

        public override string ToString()
        {
            string output;

            output = "_________________________________\n";
            output += "Employee ID          : " + id + "\n";
            output += "Employee Name        : " + name + "\n";
            output += "Employee BasicSalary : " + basicSalary + "\n";
            output += "Employee HRA         : " + HRA + "\n";
            output += "Employee TA          : " + TA + "\n";
            output += "Employee DA          : " + DA + "\n";
            output += "_______________________________\n";

            return output;
        }
    }
    }
