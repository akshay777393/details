﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class CarParking
    {
        int[] num = new int[5];

        public static void Main()
        {
            CarParking obj1 = new CarParking();
            
            bool flag = true;
            
            do
            {
                int menu;

                Console.WriteLine("\n\n--------------------------\n");
                Console.WriteLine("    1 : Parking Car");
                Console.WriteLine("    2 : Unparking Car");
                Console.WriteLine("    3 : View parking slot");
                Console.WriteLine("    4 : Exit");
                Console.WriteLine("\n--------------------------\n\n");

                Console.Write("Enter the menu option :  ");
                menu = Convert.ToInt32(Console.ReadLine());
                Console.Write("\n");

                switch (menu)
                {

                    case 1:
                        obj1.Parking();
                        Console.ReadKey();
                        break;

                    case 2:
                        obj1.Unparking();
                        Console.ReadKey();
                        break;

                    case 3:
                        obj1.Veiw();
                        Console.ReadKey();
                        break;

                    case 4:
                        Console.WriteLine("");
                        flag = false;
                        break;

                    default:
                        Console.WriteLine("Sorry.!!!   Enter the correct  menu option....");
                        break;
                }
            } while (flag);
        }

        public void Parking()
        {
            for(int i=0;i<5;i++)
            {
                if(num[i]==0)
                {
                    num[i] = 1;
                    Console.WriteLine("\nYour Car successfully parked in slot : {0} ", i + 1);
                    break;
                }
            }
        }

        public void Unparking()
        {
            int poss;
            Console.Write("\nEnter your car slot : ");
            poss = Convert.ToInt32(Console.ReadLine());
            Console.Write("\n");

            if (num[poss-1] == 1)
            {
                num[poss-1] = 0;
                Console.WriteLine("Your Car successfully Unparked   ");
            }
            else
            {
                Console.WriteLine("Sorry !!!  Wrong slot............");
            }
        }

        public void Veiw()
        {
            string park;
            park = "Parked";

            for (int i = 0; i < 5; i++)
            {
                if(num[i]==1)
                {
                    park = "Parked";
                }
                else
                {
                    park = "Unparked";
                }

                Console.WriteLine("Slot {0} : {1} ", i + 1,park);
            }
        }

    }
}
