﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp.ThreadDemo
{
    class JoinThread
    {
        public static void Main()
        {
            Thread thread1 = Thread.CurrentThread;
            thread1.Name="Main thread";

            Console.WriteLine("\nMain Method : " + thread1.Name);
            ThreadStart threadStart1 = new ThreadStart(ChaidThread1);

            Thread subthread1 = new Thread(ChaidThread1);
            Thread subthread2 = new Thread(ChaidThread2);


            subthread1.Start();
            subthread2.Start();

            subthread2.Join();

            Console.WriteLine();
            Console.WriteLine("\nMain Method Completed");

            Console.ReadLine();
        }




        public static void ChaidThread1()
        {
           // Thread.Sleep(100);

            Console.WriteLine("\nI am in Chaild Thread1");

            for (int i = 1; i <= 10; i++)
            {
               // Thread.Sleep(100);
                Console.Write(i + " ");
            }
            Console.WriteLine();
            Console.WriteLine("Chaild thread1 Completed");
            
        }


        public static void ChaidThread2()
        {
           // Thread.Sleep(100);

            Console.WriteLine("\nI am in Chaild Thread2");

            for(int i=11;i<=20;i++)
            {
               // Thread.Sleep(100);
                Console.Write(i + " ");
            }
            Console.WriteLine();
            Console.WriteLine("Chaild thread2 Completed");
            
        }
    }


}
