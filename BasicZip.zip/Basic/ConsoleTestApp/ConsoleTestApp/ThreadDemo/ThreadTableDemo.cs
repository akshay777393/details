﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp.ThreadDemo
{
    class ThreadTableDemo
    {
        public static void Main()
        {
            Table table5 = new Table(5,500);
            Thread thread1 = new Thread(table5.GenerateTable);
            thread1.Start();

            Table table10 = new Table(10, 500);
            Thread thread2 = new Thread(table5.GenerateTable);
            thread2.Start();

            Console.ReadKey();


        }
    }
    class Table
    {
        private int _number;
        private int _sleep;

        public Table(int target,int tar1)
        {
            _number = target;
            _sleep = tar1;
        }

        public void GenerateTable()
        {
           // Thread.Sleep(_sleep);

            for(int iteration=1; iteration<=10; iteration++)
            {
                Thread.Sleep(_sleep);

                Console.WriteLine("{0} * {1} = {2}", iteration,_number,(iteration*_number));
            }
        }
    }

}
