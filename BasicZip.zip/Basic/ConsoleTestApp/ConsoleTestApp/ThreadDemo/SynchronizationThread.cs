﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp.ThreadDemo
{
    class SynchronizationThread
    {
        public static void Main()
        {
            Printer print1 = new Printer();

            Thread thread1 = new Thread(print1.PrintTable);
            Thread thread2 = new Thread(print1.PrintTable);

            thread1.Start();
            thread2.Start();

            Console.ReadKey();

        }


    }
    class Printer
    {
        public void PrintTable()
        {
            lock (this)
            {
                for (int i=1;i<=10;i++)
                {
                    Thread.Sleep(100);
                    Console.WriteLine("*** "+i);
                }
            }
        }
    }
}
