﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;



namespace ConsoleTestApp.CollectionClass
{
    class ShoppingCart
    {
        public static void Main()
        {

            Hashtable productTable = new Hashtable();
            Hashtable cart = new Hashtable();
            

            productTable.Add(101, new Product { Product_ID = 101, Product_Name = "Pista    ", UnitPrice = 120, Quantity=0,Ammount=0 });
            productTable.Add(102, new Product { Product_ID = 102, Product_Name = "Rice     ", UnitPrice = 42, Quantity = 0, Ammount = 0 });
            productTable.Add(103, new Product { Product_ID = 103, Product_Name = "Nuts     ", UnitPrice = 200, Quantity = 0, Ammount = 0 });
            productTable.Add(104, new Product { Product_ID = 104, Product_Name = "EveryDay ", UnitPrice = 260, Quantity = 0, Ammount = 0 });
            productTable.Add(105, new Product { Product_ID = 105, Product_Name = "Soap     ", UnitPrice = 20, Quantity = 0, Ammount = 0 });
            productTable.Add(106, new Product { Product_ID = 106, Product_Name = "Ice Cream", UnitPrice = 20, Quantity = 0, Ammount = 0 });

            do
            {
                int option;

                Console.WriteLine("\n\n------------------------\n");
                Console.WriteLine("  1 : Add to cart");
                Console.WriteLine("  2 : View cart");
                Console.WriteLine("  3 : Cheakout Cart");
                Console.WriteLine("  4 : Exit");
                Console.WriteLine("\n------------------------\n\n");

                Console.WriteLine("Enter the menu option....");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {

                    case 1:

                        Console.WriteLine("                       PRODUCT DETAILS ");
                        Console.WriteLine("------------------------------------------------------------");
                        Console.WriteLine("  Product Id\t|   Product Nmame\t|   Unit Price\t   |");
                        Console.WriteLine("------------------------------------------------------------");

                        Product product;

                        if(productTable!=null)
                        {
                            ICollection key = productTable.Keys;

                            foreach(int k in key)
                            {
                                product = ((Product)productTable[k]);
                                Console.WriteLine(" "+product.Product_ID + "        \t| " + product.Product_Name + "        \t| " + product.UnitPrice+ "    \t   |" );
                            }
                        }
                        else
                        {
                            Console.WriteLine("Sorry...!   No product available in the store");
                        }
                        
                        Console.WriteLine("------------------------------------------------------------");

                        Console.Write("\nEnter Product ID : ");
                        int productid = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter Product Quantity :");
                        int quantity = Convert.ToInt32(Console.ReadLine());


                        product = (Product)productTable[productid];

                        product.Quantity = quantity;

                        product.Ammount = product.UnitPrice * product.Quantity;

                        //if (cart == null)
                        //{
                        //    cart = new Hashtable();
                        //}

                      
                        cart.Add(productid, product);

                        Console.WriteLine("Product add suceefully added to the cart");
                        Console.ReadKey();
                        
                        break;

                    case 2:

                        Console.WriteLine("\n----------------------------- CART DETAILS -------------------------------");
                        Console.WriteLine("**************************************************************************");
                        Console.WriteLine(" Product Id\t| Product Nmame\t| Unit Price\t| Quantity\t| Ammount");
                        Console.WriteLine("**************************************************************************");

                        if (cart != null)
                        {
                            ICollection key = cart.Keys;

                            foreach (int k in key)
                            {
                                product = ((Product)cart[k]);

                                Console.WriteLine(" "+product.Product_ID + "     \t| " + product.Product_Name + " \t| " + product.UnitPrice + "     \t| " + product.Quantity + "         \t| "+ product.Ammount);
                                //For display..........
                            }
                            Console.WriteLine("**************************************************************************");
                        }
                        else
                        {
                            Console.WriteLine("No product available in the cart");
                        }

                        break;

                    case 3:
                        double Total=0;
                        
                        Console.WriteLine("\n--------------------------------------------------------------------------");
                        Console.WriteLine(" Product Id\t| Product Nmame\t| Unit Price\t| Quantity\t| Ammount  |");
                        Console.WriteLine("--------------------------------------------------------------------------");

                        if (cart != null)
                        {
                            ICollection key = cart.Keys;

                            foreach (int k in key)
                            {
                                product = ((Product)cart[k]);

                                Console.WriteLine(" " + product.Product_ID + "     \t| " + product.Product_Name + " \t| " + product.UnitPrice + "    \t| " + product.Quantity + "         \t| " + product.Ammount + " \t|");
                                //For display..........
                                Total += product.Ammount;
                            }
                            Console.WriteLine("--------------------------------------------------------------------------");
                            Console.WriteLine("\n__________________________________________________________TOTAL = "+Total);
                            Console.WriteLine("\nTHANK YOU FOR SHOPPING..........................");
                            Console.ReadKey();
                            System.Environment.Exit(0);

                        }
                        else
                        {
                            Console.WriteLine("No product available in the cart");
                        }

                        break;

                    case 4:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Sorry.!!!   Enter the correct  menu option....");
                        break;
                }
            } while (true);
        }

    }

    class Product
    {
        public int Product_ID { get; set; }
        public string Product_Name { get; set; }
        public int UnitPrice { get; set; }
        public int Quantity { get; set; }
        public int Ammount { get; set; }
    }     
}

