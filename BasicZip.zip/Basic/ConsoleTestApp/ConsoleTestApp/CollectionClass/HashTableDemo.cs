﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleTestApp.CollectionClass
{
  
    class HashTableDemo
    {
        static void Main(string[] args)
        {

            Hash_Table();

        }

        public static void Hash_Table()
        {
            Hashtable ht = new Hashtable();

            ht.Add("001", "Zara Ali");
            ht.Add("002", "Joe Holzner");
            ht.Add("003", "Amlan");
            ht.Add("004", "Arif");
            ht.Add("005", "Saikia");
            ht.Add("006", "Ritesh");
            ht.Add("007", "Holder");

            if (ht.ContainsValue("Nehrin"))
            {
                Console.WriteLine("The name Already exists");
            }
            else
            {
                   ht.Add("008", "Nehrin");
            }

            foreach (DictionaryEntry name in ht)
            {
                Console.WriteLine("{0} - {1} ", name.Key, name.Value);
            }
            Console.ReadLine();

        }
    }

}
