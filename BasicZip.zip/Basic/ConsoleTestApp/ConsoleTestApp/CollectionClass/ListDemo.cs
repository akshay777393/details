﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.CollectionClass
{
    class ListDemo
    {
        public static void Main()
        {

            List<string> names = new List <string>();

            names.Add("Sono Jaiswal");
            names.Add("Ankit");
            names.Add("Arun");
            names.Add("Irfan");
            names.Add("Peter");
            names.Add("Ankit");

            names.Remove("Peter");
           // names.Add(123);
            names.RemoveAt(0);
            names.RemoveRange(2,2);
            names.Reverse();
            names.Sort();



            names.Insert(0, "Gogul");

            foreach(var name in names)
            {
                Console.WriteLine(name);
            }

            Console.ReadLine();
        }

    }
}
