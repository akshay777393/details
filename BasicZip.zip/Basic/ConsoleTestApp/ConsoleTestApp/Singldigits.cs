﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Singldigits
    {
        int number;

        public void ReadData()
        {
            Console.WriteLine("Enter the number : ");
            number = Convert.ToInt32(Console.ReadLine());
        }

       public int FindDigitSum(int n)
       {
            int lastDigit, digitSum=0;
            do
            {
                lastDigit = n % 10;
                digitSum += lastDigit;
                n /= 10;
            } while (n > 0);
            return digitSum;

       }

        public void DigitsSum()
        {
            int sum;
            sum = FindDigitSum(number);

                while (sum > 9)
                {
                   sum= FindDigitSum(sum);
                    
                }
            Console.WriteLine("Digit sum =  " + sum);

        }

        public static void Main()
        {
            Singldigits Objdigit1 = new Singldigits();
            Objdigit1.ReadData();
            Objdigit1.DigitsSum();
           // Objdigit1.DisplayData();

            Console.ReadKey();
        }


    }
}
