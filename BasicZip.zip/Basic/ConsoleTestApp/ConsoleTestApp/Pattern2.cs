﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern2
    {
        int number;
        public void ReadData()
        {
            Console.WriteLine("Enter the number : ");
            number = Convert.ToInt32(Console.ReadLine());
        }


        public void print()
        {
            for (int no = 1; no <= number; no++)
            {
                for (int i = 1; i <= no; i++)
                {
                    Console.Write(" "+i+" ");
                }
                Console.WriteLine("\n");
            }

        }

        public static void Main()
        {
            Pattern2 Objdigit1 = new Pattern2();
            Objdigit1.ReadData();
            Objdigit1.print();

            Console.ReadKey();
        }
    }
}
