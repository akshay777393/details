﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AbstractDemo1
    {
        public static void Main()
        {
            Square square1 = new Square();
            square1.Readvalue();
            square1.FindArea();
            square1.Display(square1.FindArea());

            Retangle ret1 = new Retangle();
            ret1.Readvalue();
            ret1.FindArea();
            ret1.Display(ret1.FindArea());

            Circle cir1 = new Circle();
            cir1.Readvalue();
            cir1.FindArea();
            cir1.Display(cir1.FindArea());

            Console.ReadKey();

        }

    }

    abstract class shape
    {
        double Area;
        public const double PI = 3.14;

        public void Display(double x)
        {
            Area = x;
            Console.WriteLine("The  Area of shape : {0}", Area);
            Console.WriteLine("---------------------------------\n");
        }

        public abstract double FindArea();
    }

    class Square : shape
    {
        int sideLength;

        public void Readvalue()
        {
            Console.WriteLine("Enter the length of Square  ");
            sideLength = Convert.ToInt32(Console.ReadLine());
        }

        public override double FindArea()
        {
            double area;
            area = sideLength * sideLength;

            return area;
        }

    }

    class Retangle : shape
    {
        int Length,breadth;

        public void Readvalue()
        {
            Console.WriteLine("Enter the  Length of Retengle  ");
            Length = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the  breadth of Retengle  ");
            breadth = Convert.ToInt32(Console.ReadLine());
        }
        public override double FindArea()
        {
            double area;
            area = Length * breadth;

            return area;
        }
      
    }

    class Circle : shape
    {
        int Radius;

        public void Readvalue()
        {
            Console.WriteLine("Enter the Radius of Circle  ");
            Radius = Convert.ToInt32(Console.ReadLine());
        }
        public override double FindArea()
        {
            double area;
            area =( PI * Radius* Radius);

            return area;
        }

    }
}