﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Amstrong
    {
        int value;
        int asnumber = 0;

        public void ReadData()
        {
            Console.WriteLine("\n\nEnter the value : ");
            value = Convert.ToInt32(Console.ReadLine());
        }

        public void Amstrongornot()
        {
            int num,Digit=0, last;

            num = value;
            
            do
            {
                num = num / 10;
                Digit++;
            } while (num > 0);

            num = value;

            do
            {
                last = num % 10;
                asnumber = asnumber +Convert.ToInt32((Math.Pow(last, Digit)));
                num /= 10;
            } while (num > 0);
           
        }
        
        public void display()
        {
            if(value== asnumber)
            {
                Console.WriteLine("\n\n{0} is Armstorng number ",value);
            }
            else
            {
                Console.WriteLine("\n\n{0} is not Armstorng number ", value);
            }
        }

        public static void Main()
        {
            Amstrong Obj1 = new Amstrong();
            Obj1.ReadData();
            Obj1.Amstrongornot();
            Obj1.display();


            Console.ReadKey();

        }
    }
}
