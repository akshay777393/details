﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
   
    


    class Static
    {

        int i = 10;
        static int j = 10;

        public  void  demo()
        {
           
            Console.WriteLine("\nThe value of i = " + i);
            Console.WriteLine("The value of j = " + j);
            i++;
            j++;
        }

        public static void Main()
        {
            Static obj1 = new Static();
            Static obj2 = new Static();
            Static obj3 = new Static();

            obj1.demo();
            //obj1.demo();
            obj2.demo();
            obj3.demo();
            //obj1.demo();


            Console.ReadKey();
        }

    }
}
