﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class BinaryToDecimal
    {
        int Binary, Decimal=0;

        public void ReadData()
        {
            Console.WriteLine("\n\nEnter the Binary value : ");
            Binary = Convert.ToInt32(Console.ReadLine());
        }

        public void Convertion()
        {
            int num, rem, i=0;

            num = Binary;
            do
            {
                rem = num % 10;
                Decimal=Decimal+(rem * (Convert.ToInt32( Math.Pow(2,i))));
                num /= 10;
                i++;
            } while (num > 0);
        }

        public void display()
        {
            
                Console.WriteLine("\n\nDecimal = {0} \nBinary number = {1} ", Binary, Decimal);
           
        }

        public static void Main()
        {
            BinaryToDecimal Obj1 = new BinaryToDecimal();
            Obj1.ReadData();
            Obj1.Convertion();
            Obj1.display();


            Console.ReadKey();

        }
    }
}
