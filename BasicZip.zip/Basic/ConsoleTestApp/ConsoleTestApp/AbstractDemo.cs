﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AbstractDemo
    {

        public static void Main()
        {

            XYZ xyz = new XYZ();

            xyz.Display();
            xyz.Check();

           // xyz.;

            ABC.FindSum(10, 20);
            XYZ.FindSum(40, 20);

            Console.WriteLine("Sum opf number : {0}", XYZ.FindSum(20, 40));
            Console.ReadKey();
        }
    }

    abstract class ABC
    {
        //int val1;
        //static int val2;
        const double pi =3.14;

        public abstract void Display();

        public static int FindSum(int v1,int v2)
        {
            return (v1 + v2);
        }

        public static void Print()
        {
            Console.WriteLine("I am in print method");
        }

    
    }

    class XYZ : ABC
    {

        public void Check()
        {
            Console.WriteLine("I am in Check method");
        }

        public override void Display()
        {
            Console.WriteLine("I am in Display method");
        }

    }

}
