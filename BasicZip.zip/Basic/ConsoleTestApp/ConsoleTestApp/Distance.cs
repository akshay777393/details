﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Distance
    {
        int feet, inches;


        public Distance()
        {

        }

        public Distance(int feet,int inches)
        {
            this.feet = feet;
            this.inches = inches;
        }

        public void DisplayDistance()
        {
            Console.WriteLine("\tFeet : {0} Inches : {1}",feet,inches);
        }

        public void ReadDistance()
        {
            Console.WriteLine("Enter the value of feet :");
            feet = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the value of inch :");
            inches = Convert.ToInt32(Console.ReadLine());

        }

        public void AddDistance(Distance objDistance1, Distance objDistance2)
        {
            feet = objDistance1.feet + objDistance2.feet;
            inches = objDistance1.inches + objDistance2.inches;

            if (inches >= 12)
            {
                feet++;
                inches %= 12;
            }
        }

        public static Distance operator +(Distance d1,Distance d2)
        {
            Distance d = new Distance();

            d.feet = d1.feet + d2.feet;
            d.inches = d1.inches + d2.inches;
            if (d.inches >= 12)
            {
                d.feet++;
                d.inches %= 12;
            }
            return d;
        }

        public Distance AddDistance(Distance d2)
        {
            Distance d1 = new Distance();

            d1.feet = feet + d2.feet;
            d1.inches = inches + d2.inches;
            if (d1.inches >= 12)
            {
                d1.feet++;
                d1.inches %= 12;
            }
            return d1;
        }

        public static Distance operator -(Distance d1, Distance d2)
        {
            Distance d = new Distance();

            int k, m,n;
           // d1.feet = d1.feet * 12;
            //d2.feet = d2.feet * 12;

            k = (d1.feet * 12)+ d1.inches;
            m = (d2.feet * 12 )+ d2.inches;

           //(k >= m) ? (n = k - m) : ( n = m - k);


            if (k>=m)
            {
                n = k - m;
            }
            else
            {
                n = m - k;
            }
            d.feet = n / 12;
            d.inches = n % 12;

            return d;
        }

        public static void  Main()
        {
            Distance dis1 = new Distance();
            Distance dis2 = new Distance();
            Distance dis3 = new Distance();
            Distance dis4 = new Distance();

            Distance dis5;
            Distance dis6;

            // Distance dis1 = new Distance();

            Console.WriteLine("\nEnter the value of Distance 1");
            Console.WriteLine("--------------------------------");
            dis1.ReadDistance();
            
            Console.WriteLine("\nEnter the value of Distance 2");
            Console.WriteLine("---------------------------------");
            dis2.ReadDistance();
            

            dis3=dis1.AddDistance(dis2);
            Console.WriteLine("\n_____________________________Distance__");
            dis3.DisplayDistance();

            dis4.AddDistance(dis1, dis2);
            Console.WriteLine("\n_____________________________Distance__");
            dis4.DisplayDistance();

            dis5 = dis1 + dis2;
            Console.WriteLine("\n_____________________________Distance__");
            dis5.DisplayDistance();

            dis6 = dis1 - dis2;
            Console.WriteLine("\n_____________________________Distance_Differnce");
            dis6.DisplayDistance();

            //int h = 3, e = 6;
            //int p = 3 + 6;

            //Console.WriteLine("\n_____________________________{0}    {1}   =   {2}",h,e,p);
            //dis6.DisplayDistance();

            Console.ReadKey();
        }
    }
}
