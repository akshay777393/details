﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Fibnocci
    {
        int number;

        public void ReadData()
        {
            Console.WriteLine("Enter the number : ");
            number = Convert.ToInt32(Console.ReadLine());
        }

        public void findfibbinocci()
        {
            int val1 = -1, val2 = 1,limit=0,result=0;
            Console.WriteLine("________________\n ");
            do
            {
                result = val1 + val2;
                val1 = val2;
                val2 = result;
                limit++;
                Console.WriteLine(" " + result);

            } while (limit < number);
        }

        
        public static void Main()
        {
            Fibnocci Obj1 = new Fibnocci();
            Obj1.ReadData();
            Obj1.findfibbinocci();

            Console.ReadKey();
        }
    }
}
