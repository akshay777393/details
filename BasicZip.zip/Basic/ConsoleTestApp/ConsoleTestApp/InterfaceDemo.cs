﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InterfaceDemo
    {

        public static void Main()
        {
            Sub s1 = new Sub();
            s1.Display();

            Console.ReadKey();

        }
    }

    interface Base1
    {
        void Display();
    }

    class Sub : Base1
    { 
        public  void Display()
        {
            Console.WriteLine("I am in sub");
        }
    }

    class Base2
    {
       public void Display()
      {
            Console.WriteLine("I am in base2");
        }
    }
}
