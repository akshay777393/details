﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeaklyTest1
{
    class AbstractAccount
    {

        public static void Main()
        {
            SBAccount Obj1 = new SBAccount();
            Obj1.ReadData();
            Obj1.CalculateInterest();
            Obj1.display();

            SBAccount Obj2 = new SBAccount();
            Obj2.ReadData();
            Obj2.CalculateInterest();
            Obj2.display();

            Console.ReadKey();
        }

    }



    public abstract class Account
    {
        public  readonly int AccountId;
        public string name;
        public double PrincipalAmount,intersRate,year, Total;
        static int temp = 1000;
        
        public abstract void CalculateInterest();

        public Account()
        {
            AccountId=temp;
            temp++;
            //AccountId++;
        }
    }

  

    public class SBAccount : Account
    {
        public void ReadData()
        {
            Console.WriteLine("Enter the Account Name :");
            name =Console.ReadLine();
            Console.WriteLine("Enter the principal Amount :");
            PrincipalAmount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the rate of interst :");
            intersRate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number of years :");
            year = Convert.ToInt32(Console.ReadLine());

        }

        public override void CalculateInterest()
        {
            Total = PrincipalAmount * (1 + (year * intersRate));
        }
        public void display()
        {
            
            Console.WriteLine("\n---------------------------------\n");
          
            Console.WriteLine("Acount Name\t\t:" + name);
            Console.WriteLine("Acount number\t\t:" + AccountId);
            Console.WriteLine("Principal Amount\t:" + PrincipalAmount);
            Console.WriteLine("Rate of interst\t\t:" + intersRate);
            Console.WriteLine("Total amount\t\t:" + Total);
            
            Console.WriteLine("\n---------------------------------\n");

        }

    }

}
