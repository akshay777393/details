﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeaklyTest1
{
    class MenuProgram
    {
        public static void Main()
        {
            bool flag = true;

            do
            {
                int menu;

                Console.WriteLine("\n\n---------------------------------------");
                Console.WriteLine("1 : Given number Prime or Not");
                Console.WriteLine("2 : Prime number between 2 intervel");
                Console.WriteLine("3 : N Prime number");
                Console.WriteLine("4 : Exit");
                Console.WriteLine("---------------------------------------\n\n");

                Console.WriteLine("Enter the menu option....");
                menu = Convert.ToInt32(Console.ReadLine());
                switch (menu)
                {

                    case 1:
                        Prime obj1 = new Prime();
                        obj1.ReadData();
                        obj1.Find();
                        obj1.display();
                        break;

                    case 2:
                        PrimeN Obj1 = new PrimeN();
                        Obj1.ReadData();
                        Obj1.Find();
                        break;

                    case 3:
                        Nprime Objdigit1 = new Nprime();
                        Objdigit1.ReadData();
                        Objdigit1.Find();
                        break;

                    case 4:
                        Console.WriteLine("");
                        flag = false;
                        break;

                    default:
                        Console.WriteLine("Sorry.!!!   Enter the correct  menu option....");
                        break;
                }
            } while (flag);
        }
    }


    //----------------------------------------------------------------------------------------------------------------------------------------

    class Prime
    {
        int value;
        string result;

        public void ReadData()
        {
            Console.WriteLine("\n\nEnter a number : ");
            value = Convert.ToInt32(Console.ReadLine());
        }

        public void Find()
        {
            bool flag = true;

            for (int no = 2; no < value; no++)
            {
                if (value % no == 0)
                {
                    flag = false;
                    break;
                }
            }
            if (flag)
            {
                result = "PRIME";
            }
            else
            {
                result = "NOT PRIME";
            }

            if (value == 1)
            {
                result = " Composite";
            }
        }

        public void display()
        {
            Console.WriteLine("The given number {0} is {1} number", value, result);
        }

    }

    //----------------------------------------------------------------------------------------------------------------------------------

    class PrimeN
    {

        int value1,value2;


        public void ReadData()
        {
            Console.WriteLine("\n Enter the start limit : ");
            value1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n Enter the ending limit : ");
            value2 = Convert.ToInt32(Console.ReadLine());
        }


        public void Find()
        {

            for (int no = value1; no <= value2; no++)
            {
                bool flag = true;

                for (int i = 2; i < no; i++)
                {
                    if (no % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    Console.WriteLine("\t" + no);
                }
            }


        }

    }


//--------------------------------------------------------------------------------------------------------------------------

    class Nprime
    {

        int value;


        public void ReadData()
        {
            Console.WriteLine("\n Enter the limit : ");
            value = Convert.ToInt32(Console.ReadLine());
        }


        public void Find()
        {
            int count = 1;

            for (int no = 2; count <= value; no++)
            {
                bool flag = true;

                for (int i = 2; i < no; i++)
                {
                    if (no % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    Console.WriteLine("\t" + no);
                    count++;
                }
            }


        }
    }
        
}
