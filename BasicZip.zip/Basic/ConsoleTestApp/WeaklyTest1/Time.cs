﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeaklyTest1
{
    class Time
    {
        int hour,min, sec;
        //public Time()
        //{
        //}
        //public Time(int hour, int min, int sec)
        //{
        //    this.hour = hour;
        //    this.min = min;
        //    this.sec = sec;
        //}

        public void Displaytime()
        {
            Console.WriteLine("\tHour : {0} Minute : {1} secound : {2}\t\t {0}:{1}:{2}", hour, min,sec);
        }

        public void ReadTime()
        {
            Console.WriteLine("Enter the value of hour :");
            hour = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the value of minute :");
            min = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the value of secound :");
            sec = Convert.ToInt32(Console.ReadLine());

            if (sec >= 60)
            {
                min++;
                sec %= 60;
            }
            if (min >= 60)
            {
                hour++;
                min %= 60;
            }
            if (hour >=24)
            {
                hour %= 24;
            }
        }

     
        public static Time operator +(Time d1, Time d2)
        {
            Time t = new Time();

            t.hour = d1.hour + d2.hour;
            t.min = d1.min + d2.min;
            t.sec = d1.sec + d2.sec;

            if (t.sec >= 60)
            {
                t.min++;
                t.sec %= 60;
            }
            if (t.min >= 60)
            {
                t.hour++;
                t.min %= 60;
            }
            if (t.hour >=24)
            {
                t.hour %= 24;
            }
            return t;
        }

        public static Time operator -(Time t1, Time t2)
        {
            Time t = new Time();

            int k, m, n;
            t1.hour = t1.hour * 3600;
            t2.hour = t2.hour * 3600;

            t1.min = t1.min * 60;
            t2.min = t2.min * 60;

            k = t1.hour + t1.min + t1.sec;
            m = t2.hour + t2.min + t2.sec;

            n =Math.Abs(k-m);

            t.sec = n % 60;
            n = n / 60;
            t.min = n % 60;
            n = n / 60;
            t.hour = n % 60;

            return t;
        }

        public static void Main()
        {
            Time tim1 = new Time();
            Time tim2 = new Time();
         

            Time tim3;
            Time tim4;

          

            Console.WriteLine("\nEnter the value of Time 1");
            Console.WriteLine("--------------------------------");
            tim1.ReadTime();

            //tim1.Displaytime();

            Console.WriteLine("\nEnter the value of Time 2");
            Console.WriteLine("---------------------------------");
            tim2.ReadTime();

            // tim1.Displaytime();


            tim3 = tim1 + tim2;
            Console.WriteLine("\n----------------Time Adition-------------------");
            tim3.Displaytime();

            tim4 = tim1 - tim2;
            Console.WriteLine("\n----------------Time Differnce-------------------");
            tim4.Displaytime();

            Console.ReadKey();
        }
    }
}
