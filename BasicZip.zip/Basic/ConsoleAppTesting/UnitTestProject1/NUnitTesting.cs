﻿using System;
using System.Collections.Generic;
using System.Text;
using ConsoleApp2Testing;
using NUnit.Framework;


namespace Calculater
{
    [TestFixture]
    class NUnitTesting
    {
        [TestCase]
        public void TestAddMethod()
        {
            DemoTest p1 = new DemoTest();
            Assert.AreEqual(31, p1.Add(20, 11));
            // Assert.AreNotEqual(31, p1.Add(20, 11));

        }
        [TestCase]
        public void TestSubMethod()
        {
            DemoTest p1 = new DemoTest();
            NUnit.Framework.Assert.AreEqual(9, p1.Sub(20, 11));
        }
    }
    
}
