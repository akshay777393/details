using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp2Testing;
//using NUnit.Framework;


namespace UnitTestProject1
{
    [TestClass]
    public class UnitTestCalculater
    {
        [TestMethod]
        public void TestAddMethod()
        {
            DemoTest p1 = new DemoTest();
            Assert.AreEqual(31,p1.Add(20, 11));
           // Assert.AreNotEqual(31, p1.Add(20, 11));
           
        }
        [TestMethod]
        public void TestSubMethod()
        {
            DemoTest p1 = new DemoTest();
            Assert.AreEqual(9, p1.Sub(20, 11));
        }
    }

}
