﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PocketMoneyDTO.DTO
{
    public class PocketMoneyDto
    {
        private int SiNo;
        private string description;
        private string type;
        private double amount;
        private double balance;


        public int SINo
        {
            get { return SiNo; }
            set { SiNo = value; }
        }


        public string Description
        {
            get { return description; }
            set { description = value; }
        }


        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public double Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }

    }
}
