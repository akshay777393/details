﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace PocketMoneyDSL.Helper
{
    class DBHelper
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = null;

            String ConnectionStrings = null;


            try
            {
                //ConnectionString = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\1028260\\Desktop\\AJMAL\\WindowsApplication1\\WindowsApplication1\\StudentDB.mdf; Integrated Security = True";
                ConnectionStrings = ConfigurationManager.ConnectionStrings["pocketmoneystring"].ConnectionString;
                con = new SqlConnection(ConnectionStrings);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("****error : DBHelper.cs:GetConnection:" + ex.Message.ToString());
            }
            return con;


        }
    }
}
