﻿using System;
using System.Collections.Generic;
using System.Text;
using PocketMoneyDSL.Helper;
using System.Data.SqlClient;
using PocketMoneyDTO.DTO;

namespace PocketMoneyDSL.PocketMoneyDL
{
    public class MoneyDl
    {
        public static int MoneyInsertDL(PocketMoneyDto money)
        {
            int output = 0;
            string sql = "";

            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "INSERT INTO PocketMoney(SiNo,Description,Type,Amount,Balance) values(";
                sql = sql + money.SINo + ",";
                sql = sql + "'" + money.Description + "',";
                sql = sql + "'" + money.Type + "',";
                sql = sql + money.Amount + ",";
                sql = sql + money.Balance + "')";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();

            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : MoneyDl.cs:MoneyInsertDL:" + exe.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
    }
}
