﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoneyDTO.DTO;
using PocketMoneyBLL.BL;

namespace PocketMoneyPL.PL
{
    public partial class PocketMoney : Form
    {
        public PocketMoney()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            PocketMoneyDto pocketMoney = null;
            int output = 0;
            try
            {



                if (txtSiNo.Text == string.Empty && txtDption.Text == string.Empty && txtAmmount.Text == string.Empty)
                {
                    lblMessage.Text = "! All fields are mandatory. Enter Data to all fields";
                    return;
                }
                else if (txtSiNo.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter SiNo";
                    return;
                }
                else if (txtDption.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter Description";
                    return;
                }
                //else if (cmbState.SelectedIndex == -1)
                //{
                //    lblMessage.Text = "Please select State!";
                //    return;
                //}
                else if (txtAmmount.Text == string.Empty)
                {
                    lblMessage.Text = "! Enter Amount";
                    return;
                }
               
                else
                {

                    string TypeValue;

                    if (rdbCredit.Checked == true)
                    {
                        TypeValue = "Credit";
                    }
                    else
                    {
                        TypeValue = "Debit";
                    }

                    pocketMoney = new PocketMoneyDto();


                    pocketMoney.SINo = Convert.ToInt32(txtSiNo.Text);
                    pocketMoney.Description = txtDption.Text;
                    pocketMoney.Type = TypeValue;
                    pocketMoney.Amount = Convert.ToInt32(txtAmmount.Text);
                    pocketMoney.Balance = Convert.ToInt64("0");



                    output = PocketMoneyBl.MoneyInsertBL(pocketMoney);


                    if (output > 0)
                    {
                        lblMessage.Text = "Success";
                     
                    }
                    else
                    {
                        lblMessage.Text = "Fail";
                    }
                }

            }
            catch (Exception ef)
            {
                lblMessage.Text = ef.Message.ToString();
            }
        }
    }
}
