﻿using System;
using System.Collections.Generic;
using System.Text;
using PocketMoneyDTO.DTO;
using PocketMoneyDSL.PocketMoneyDL;

namespace PocketMoneyBLL.BL
{
    public class PocketMoneyBl
    {

        public static int MoneyInsertBL(PocketMoneyDto address)
        {
            int output = 0;

            try
            {
                output = MoneyDl.MoneyInsertDL(address);
            }
            catch (Exception exe)
            {
                Console.Out.WriteLine("****error : PocketMoneyBl.cs:MoneyInsertBL:" + exe.Message.ToString());
            }
            return output;

        }

    }
}
